import { faker } from '@faker-js/faker';
import { SectionAutomation, ProductAutomation, CustomerData, LoginData, newOrderData, OptionAutomation, AtomicOptionAutomation, AccountAutomation } from '../models/types';
import { CONFIG } from '../config/environments';

export class TestDataGenerator {
  static generateCustomerData(): CustomerData {
    return {
      name: faker.person.firstName(),
      phoneNumber: '06' + faker.string.numeric(8),
      email: faker.internet.email(),
      specialRequest: faker.lorem.sentence()
    };
  }

  static generateLoginData(): LoginData {
    return {
      phoneNumber: '06' + faker.string.numeric(8),
      password: `${faker.string.alphanumeric(8)}`
    };
  }
  static generatAccountData(): AccountAutomation {
    return {
      businessType: 'food',
      country: 'MA',
      email: faker.internet.email(),
      language: 'fr',
      managerName: faker.person.firstName(),
      phone: '+2126' + faker.string.numeric(8),
      pricingPackage: 'premium',
      restaurantName: `Account_${faker.string.alphanumeric(8)}`,
      timezone: 'Africa/Casablanca',
      reCaptchaToken: `03AFcWeA5KWyC4dkBKqoTEQj0TL2tQ0fTC4By9NnhsM0x-vxuKikHRRm950SdpdGG7EL_j3fsRy9RKEDjdPsmMiFNGEouDPd_ZnbF1Vs2N3k23SBr2LdN-evCvFn5nnCRsTjYh8QcqoOXhq6rDLsJAUlqBWnJdgIx_M8MsCr-qa1anY4bwDYcqFwmp74c1JxRdfjAKaOc7-246T360GnQ2tnlD_u4BjH_JSd6RF4Dz0qMt6RDRa1H0BWko4LeAzPrAK-fnLicX4ulp1EqnoiTnjUZdWyA506FIWJ0r24Ljt5zdCCcVbJ-nO4W9WzjuHAJgFPFDh8AJkoWj3UOkrQoMtEvpCff0PdlKVWTGpgmneDwif7n202FhV9ZtNuq9dIWBADstsSPsUl15clH_AzwRAPEkt5s_c_rVrT6lfAMLU5AVKpolwiRafnFlYXH2Y2ZLlebxVf2m5EWLaBbpBKxoIgk57N_QJRxBn8HkzOuSEeTG-2TXwOYE9gLWWcXAl7lXDdts2n9bK_040PXyukx5qPiHnfKOR7DPgXIRXNNtsN9lne2mk-k8sb-ra3hBooDMQmCCri7I7C0_Qh7Y7FB2PQCBOOR1HTowl3EhITceqcR-489SS5Dt95aG_-5rKbOiSA3Lbhg4fjflCRkApAkcgcE287EzYuX8HB9ColigvaiL82JkJaN4nlUhdtR2R6ZFe73vvY2AbsVo4n_C04NzLbAun6L1kcytB4T2AQl4bqV83IIPMlMOtuDDskmGWdS0UI4Fl_074yWHCFGmQ1YAuRWHmMrjWCzSwSO-aFV3iAfbRB5vPBbXPa3PpVyrrjsJ2wxXs5BVhjIRQpuc18G6-YGUa7kQ7vRUHsTApOb4Nz8kyD1ERMlL5O1nLnPo5UYQSZwJDOLYtk0NeoQf2frOlQQVnoQe8hyK-jUj09NvBzq5eGBRltffi9VN3jJjLFEgLcjuOFTztc64k6Aw-I1anIZHWh1ovLN0_s2kWoa3eceNX1xeI5iZrWpu-5jxnPb2O0jJFurNUVQnE0loefXtRYXsFW5sZI8wuyBVGHBML7vsJRYbrslqkruXshJlGKAGAZ2WmpHNF7omVu9-JfdrwfVapLbHhmnBWALgzAwxlKJwPR16cYN5VLcbWJMBl5ivkjk8ilPMU84bHjmTM3L9KkrWdxoZD20Q_HIgoOkfC0EP5J0euXmHOoEYmFw9Epl4tifdPuq6gzGoRRMqs3w06-2L9cCeTl2VMX59ZnhGkRDjWaG0TSdRG2LGvkAaujgUe5QdJziDTll3TIsVzmuJaxwdGF9Uh9gN8jWTtzfdmddTD60nnUzZWqNWVrhrKuaWI85ADCnztM0kimYNl9szJ486YBAGMkXAueE00V8PYH0B0naBQ9gUAzOgpHonWfWa82XQX1J1ZbMxpp0DFrLt7OKCL41-i_41q19VhWY4FBwwg7WZSly-cNtrtpJ7y_LR0DW_0wO_liNTp6IY0Az8MKCtE8nw2QgNePp2GhrE6DqAtI-VGfa20nQ5jo5K_gBDgwREi1wi6B4_wlFjS0p3wEnvoVG8GaceaMUpK-f5iTLiMxzBTpnlgSbURfSBSKGfZdBGutmOCLRTyoQ4imXdR7Nam8H08SJ3nahADPikLR2JdmcfK0wT6DdPoelxO7mZUk_v112EPwyVjn0V1mvnZ5QaVDW_LK9ka6gwCUSDSJ4x_z_1FsVAUVBMK3V0vBEZCLQOdRYpN4bper4dJ2LYrxSCB-I3gSjE222kUs6HNQbhmJ-kJLs12yzTjJyeLY6iHsaRuCrjK64Mav1b2VhxzRLCU5ySF9kEpKljbWjigbbK5CahSgMYNTw`
    };
  }
  static generateSectionData(restaurantId: string):  SectionAutomation {
    return {
      idRestaurant: restaurantId,
      name: `Section_${faker.string.alphanumeric(8)}`,
      meals: []
    };
  }

  static generateProductData(sectionId: string, menuId: string): ProductAutomation {
    return {
      id: '',
      idRestaurant: CONFIG.RESTAURANT_ID,
      status: 'active',
      name: `Product_${faker.string.alphanumeric(8)}`,
      description: faker.lorem.sentence(),
      section: sectionId,
      price: 99.99,
      options: [],
      useDefaultDiscount: false,
      discount: 0,
      menuId: menuId,
      img: {},
      sizes: [
        { name: "Petit", price: 0 },
        { name: "Moyen", price: 0 },
        { name: "Large", price: 0 }
      ],
      imgs: [{
        rawFile: {},
        path: 'blob:https://beta.daba.store/6e40332c-82fc-433b-97ad-90116a8c22c2',
      }]
    };
  }
  static generateAtomicOptionData(optionGroupId: string, menuId: string): AtomicOptionAutomation {
    return {
      optionGroup: optionGroupId,
      menuId: menuId,
      name: `AtomicOption_${faker.lorem.sentence()}`,
      pricePerUnit: 5,
    };
  }
  static generateOptionData(menuId: string): OptionAutomation {
    return {
      mandatory: false,
      maxTotalOptionsCount: 1,
      minTotalOptionsCount: 0,
      name: `Option_${faker.lorem.sentence()}`,
      menuId: menuId,
      type: "mono",
    };
  }

  static generateOrderData(restaurantId: string, sectionId: string, productId: string, paymentMethod: string): newOrderData {
    return {
      idRestaurant: CONFIG.RESTAURANT_ID,
      restaurantId: CONFIG.RESTAURANT_ID,
      idEater: '',
      address: 'X5J2+9HW, Rabat, Maroc',
      location: {lat:faker.location.latitude({ min: 33.95, max: 34.05 }),lng:faker.location.longitude({ min: -6.90, max: -6.75 })},
      instructions: faker.lorem.sentence(),
      contactless: true,
      paymentMethod: paymentMethod,
      paymentDetails: { type: '' },
      discountCodeId: '',
      driverTip: 9,
      deliveryOption: 'delivery',
      orderMenus: [{
          idMeal: productId,
          quantity: 1,
          options: [],
          size: '',
          section: sectionId
        }],
      eater: {
        name: 'string',
        phone: '06' + faker.string.numeric(8),
        email: faker.internet.email(),
        restaurantId: CONFIG.RESTAURANT_ID,
        address: {lat:faker.location.latitude({ min: 33.95, max: 34.05 }),lng:faker.location.longitude({ min: -6.90, max: -6.75 }) ,text:'Rabat, Maroc'},
    },
    orderSource:'webstore',
    isWebStore: true,
    timezone: "Africa/Casablanca",
    itemWeight:'',
    itemToBeDelivered:'',
    pickupAddress:'',
    reCaptchaToken: CONFIG.CREDENTIALS.reCaptchaToken,
    storeLocationId: CONFIG.RESTAURANT_ID + '_LOCATION_DEFAULT',
    };
  }

  static generateDiscountCodeData(restaurantId: string, sectionId: string, productId: string, paymentMethod: string): newOrderData {
    return {
      idRestaurant: CONFIG.RESTAURANT_ID,
      restaurantId: CONFIG.RESTAURANT_ID,
      idEater: '',
      address: 'X5J2+9HW, Rabat, Maroc',
      location: {lat:faker.location.latitude({ min: 33.95, max: 34.05 }),lng:faker.location.longitude({ min: -6.90, max: -6.75 })},
      instructions: faker.lorem.sentence(),
      contactless: true,
      paymentMethod: paymentMethod,
      paymentDetails: { type: '' },
      discountCodeId: '',
      driverTip: 9,
      deliveryOption: 'delivery',
      orderMenus: [{
          idMeal: productId,
          quantity: 1,
          options: [],
          size: '',
          section: sectionId
        }],
      eater: {
        name: 'string',
        phone: '06' + faker.string.numeric(8),
        email: faker.internet.email(),
        restaurantId: CONFIG.RESTAURANT_ID,
        address: {lat:faker.location.latitude({ min: 33.95, max: 34.05 }),lng:faker.location.longitude({ min: -6.90, max: -6.75 }) ,text:'Rabat, Maroc'},
    },
    orderSource:'webstore',
    isWebStore: true,
    timezone: "Africa/Casablanca",
    itemWeight:'',
    itemToBeDelivered:'',
    pickupAddress:'',
    reCaptchaToken: CONFIG.CREDENTIALS.reCaptchaToken,
    storeLocationId: CONFIG.RESTAURANT_ID + '_LOCATION_DEFAULT',
    };
  }
  static generateMarketingNotifData(restaurantId: string, sectionId: string, productId: string, paymentMethod: string): newOrderData {
    return {
      idRestaurant: CONFIG.RESTAURANT_ID,
      restaurantId: CONFIG.RESTAURANT_ID,
      idEater: '',
      address: 'X5J2+9HW, Rabat, Maroc',
      location: {lat:faker.location.latitude({ min: 33.95, max: 34.05 }),lng:faker.location.longitude({ min: -6.90, max: -6.75 })},
      instructions: faker.lorem.sentence(),
      contactless: true,
      paymentMethod: paymentMethod,
      paymentDetails: { type: '' },
      discountCodeId: '',
      driverTip: 9,
      deliveryOption: 'delivery',
      orderMenus: [{
          idMeal: productId,
          quantity: 1,
          options: [],
          size: '',
          section: sectionId
        }],
      eater: {
        name: 'string',
        phone: '06' + faker.string.numeric(8),
        email: faker.internet.email(),
        restaurantId: CONFIG.RESTAURANT_ID,
        address: {lat:faker.location.latitude({ min: 33.95, max: 34.05 }),lng:faker.location.longitude({ min: -6.90, max: -6.75 }) ,text:'Rabat, Maroc'},
    },
    orderSource:'webstore',
    isWebStore: true,
    timezone: "Africa/Casablanca",
    itemWeight:'',
    itemToBeDelivered:'',
    pickupAddress:'',
    reCaptchaToken: CONFIG.CREDENTIALS.reCaptchaToken,
    storeLocationId: CONFIG.RESTAURANT_ID + '_LOCATION_DEFAULT',
    };
  }
}