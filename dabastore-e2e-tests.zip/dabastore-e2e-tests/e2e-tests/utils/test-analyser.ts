// e2e-tests/utils/test-analyzer.ts

import fs from 'fs/promises';
import path from 'path';
import { ClaudeHelper } from '/Users/mac/Downloads/dossier sans titre/dabastore-e2e-tests/e2e-tests/helpers/claud-helper.ts';
import { ENVIRONMENTS } from '../config/environments';

export async function analyzeTestFailure(
  testName: string,
  errorLog: string,
  screenshotPath: string
) {
  // Initialize Claude helper
  const env = ENVIRONMENTS[process.env.TEST_ENV || 'local'];
  const claudeHelper = new ClaudeHelper(env.claudeApiKey || '');
  
  // Read the screenshot
  const screenshot = await fs.readFile(screenshotPath, { encoding: 'base64' });
  
  // Get AI analysis
  const analysis = await claudeHelper.analyzeTestFailure(errorLog, screenshot);
  
  // Save analysis to file
  const analysisPath = path.join(
    __dirname,
    '../failures',
    `${testName}-analysis.md`
  );
  await fs.mkdir(path.dirname(analysisPath), { recursive: true });
  await fs.writeFile(analysisPath, analysis);
  
  console.log(`Failure analysis saved to ${analysisPath}`);
  return analysis;
}