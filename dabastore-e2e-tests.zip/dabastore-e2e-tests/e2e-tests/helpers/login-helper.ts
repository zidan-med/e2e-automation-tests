import { Browser, Page, BrowserContext } from '@playwright/test';
import { BackofficeLoginPage } from '../pages/backoffice/login-page';
import { CONFIG } from '../config/environments';

export class LoginHelper {
  adminPage: Page;
  adminContext: BrowserContext;

  constructor(adminPage: Page, adminContext: BrowserContext) {
    this.adminPage = adminPage;
    this.adminContext = adminContext;
  }

  static async launch(browser: Browser): Promise<LoginHelper> {
    const context = await browser.newContext();
    const page = await context.newPage();

    const loginPage = new BackofficeLoginPage(page);
    await loginPage.navigateToBackoffice();
    await loginPage.login(CONFIG.CREDENTIALS.phone.substring(1), CONFIG.CREDENTIALS.password);

    return new LoginHelper(page, context);
  }

  async close() {
    await this.adminContext.close();
  }
}
