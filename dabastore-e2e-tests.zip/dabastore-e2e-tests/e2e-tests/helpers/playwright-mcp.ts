// helpers/playwright-mcp.ts
import connect from "@playwright/test"
import { test, expect } from '@playwright/test';


export async function connectToMCP() {
  const connection = await connect('ws://localhost:4444/');
  return connection;
}