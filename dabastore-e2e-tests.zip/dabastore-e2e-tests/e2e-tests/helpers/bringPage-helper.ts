async function bringPageToFocus(page) {
    await page.evaluate(() => {
      window.focus();
    });
  }
  