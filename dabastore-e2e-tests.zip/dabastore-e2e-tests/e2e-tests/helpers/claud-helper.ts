// Create a new file: e2e-tests/helpers/claude-helper.ts

import { Page } from '@playwright/test';
import Anthropic from '@anthropic-ai/sdk';
import Client from "@anthropic-ai/sdk;

export class ClaudeHelper {
  private claude: Client;
  
  constructor(apiKey: string) {
    this.claude = new Client({
      apiKey: apiKey
    });
  }

  async analyzePageState(page: Page, prompt: string): Promise<string> {
    // Capture current page state
    const screenshot = await page.screenshot({ encoding: 'base64' });
    const html = await page.content();
    
    // Send to Claude for analysis
    const response = await this.claude.messages.create({
      model: "claude-3-7-sonnet-20250219",
      max_tokens: 1000,
      messages: [
        {
          role: "user",
          content: [
            {
              type: "text",
              text: prompt
            },
            {
              type: "image",
              source: {
                type: "base64",
                media_type: "image/png",
                data: screenshot
              }
            }
          ]
        }
      ]
    });
    
    return response.content[0].text;
  }
  
  async suggestTestCases(appDescription: string): Promise<string> {
    const response = await this.claude.messages.create({
      model: "claude-3-7-sonnet-20250219",
      max_tokens: 2000,
      messages: [
        {
          role: "user",
          content: `Given this application description: ${appDescription}
          Generate TypeScript Playwright test scenarios covering key user flows.`
        }
      ]
    });
    
    return response.content[0].text;
  }
  
  async analyzeTestFailure(errorLog: string, screenshot: string): Promise<string> {
    const response = await this.claude.messages.create({
      model: "claude-3-7-sonnet-20250219",
      max_tokens: 1000,
      messages: [
        {
          role: "user",
          content: [
            {
              type: "text",
              text: `Analyze this test failure and suggest possible causes and fixes:
              
              ${errorLog}`
            },
            {
              type: "image",
              source: {
                type: "base64",
                media_type: "image/png",
                data: screenshot
              }
            }
          ]
        }
      ]
    });
    
    return response.content[0].text;
  }
}