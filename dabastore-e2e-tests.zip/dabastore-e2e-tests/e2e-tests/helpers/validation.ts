
interface MyObjectType {
    idRestaurant: string;
    restaurantId: string;
    idEater: string;
    address: string;
    instructions: string;
    contactless: boolean;
    paymentMethod: string;
    paymentDetails: { type: string };
    discountCodeId: string;
    driverTip: number;
    deliveryOption: string;
    orderMenus: Array<{
        idMeal: string;
        quantity: number;
        options: any[]; // You may want to specify a more specific type for 'options'
        size: string;
        section: string;
    }>;
    eater: {
        name: string;
        phone: string;
        email: string;
        restaurantId: string;
        address: { text: string };
    };
    isWebStore: boolean;
    orderSource: string;
    timezone: string;
    storeLocationId: string;
}

export function validateWebstoreOrderPayload(obj: any): obj is MyObjectType {
    // Perform validation logic here
    // Return true if the object is valid, otherwise false
    // You can add more specific validation rules as needed

    // Example validation:
    return (
        typeof obj === 'object' &&
        obj.idRestaurant === 'F88YHRE9' &&
        obj.restaurantId === 'F88YHRE9' &&
        obj.instructions === 'instructions' &&
        obj.contactless === true &&
        obj.paymentMethod === "ept" &&
        obj.deliveryOption === "pickup" &&
        obj.storeLocationId === "F88YHRE9_LOCATION_TEST" &&


        // Add more conditions for other properties
        // ...

        // Recursive validation for nested structures
        validateOrderMenus(obj.orderMenus) &&
        validateEater(obj.eater)
    );
}

function validateOrderMenus(orderMenus: any[]): orderMenus is MyObjectType['orderMenus'] {
    // Add specific validation logic for orderMenus array items
    // Return true if all items are valid, otherwise false
    // ...

    // Example validation:
    return Array.isArray(orderMenus) && orderMenus.every(item => typeof item === 'object');
}

function validateEater(eater: any): eater is MyObjectType['eater'] {
    // Add specific validation logic for the 'eater' property
    // Return true if the 'eater' property is valid, otherwise false
    // ...

    // Example validation:
    return (
        typeof eater === 'object' &&
        eater.name &&
        eater.phone === "+212697729105" &&
        eater.email === "abderrahmaneqada99@gmail.com" &&
        eater.restaurantId === "F88YHRE9"
    );
}

