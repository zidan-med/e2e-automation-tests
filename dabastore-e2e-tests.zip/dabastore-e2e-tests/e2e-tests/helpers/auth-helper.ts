import { APIRequestContext, expect } from '@playwright/test';
import { CONFIG } from '../config/environments';
import { AccountAutomation } from '../models/types';

export class AuthHelper {
  private token: string | null = null;
  async createAccount(request: APIRequestContext, accountData: AccountAutomation) {
    const response = await request.post(`${CONFIG.BACKOFFICE_API_URL}/monoRestaurant`,
      {
        data: accountData
      }
    );
    return response.json();
    
  }

  async authStart(request: APIRequestContext, phone): Promise<string> {
    //if (this.token) return this.token;

    const response = await request.post(`${CONFIG.BACKOFFICE_API_URL}/manager/signin/verify-phone`, {
      data: {authCodeTransport: 'sms', code: '000000', phone: phone, reCaptchaToken:CONFIG.CREDENTIALS.reCaptchaToken},
    });

    expect(response.status()).toBe(200);
    console.log(phone)
    const responseBody = await response.json();
    //this.token = responseBody.authToken;
    const passwordSetup = responseBody.passwordSetupToken;
    return passwordSetup
  }
  async authSetup(request: APIRequestContext, passwordSetup:string , phone): Promise<string> {
    //if (this.token) return this.token;

    const response = await request.post(`${CONFIG.BACKOFFICE_API_URL}/manager/signin/setup-password`, {
      data: {password: '06659534159@Zidan',passwordSetupToken: passwordSetup, phone: phone, reCaptchaToken:CONFIG.CREDENTIALS.reCaptchaToken},
    });
    //console.log(passwordSetup);

    expect(response.status()).toBe(200);

    const responseBody = await response.json();
    //this.token = responseBody.authToken;

    return responseBody.authToken;

  }
  async getToken(request: APIRequestContext, phone): Promise<string> {
    if (this.token) return this.token;

    const response = await request.post(`${CONFIG.BACKOFFICE_API_URL}/manager/signin/verify`, {
      data: {password: '06659534159@Zidan', phone: phone, reCaptchaToken:CONFIG.CREDENTIALS.reCaptchaToken},
    });

    expect(response.status()).toBe(200);

    const responseBody = await response.json();
    this.token = responseBody.authToken;

    return this.token!;
  }
}