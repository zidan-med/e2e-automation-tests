import { APIRequestContext } from '@playwright/test';
import { SectionAutomation, ProductAutomation, newOrderData, OrderCollection, OptionAutomation, AtomicOptionAutomation, AccountAutomation } from '../models/types';
import { CONFIG } from '../config/environments';

export class ApiHelper {
  private authToken: string;

  

  constructor(authToken: string) {
    this.authToken = authToken;
  }
  get headers() {
    return {
      'X_access_token': this.authToken,
      'Content-Type': 'application/json'
    };
  }
  async createAccount(request: APIRequestContext, accountData: AccountAutomation) {
    const response = await request.post(`${CONFIG.BACKOFFICE_API_URL}/monoRestaurant`,
      {
        data: accountData
      }
    );
    return response.json();
    
  }
  async getDiscounts(request: APIRequestContext) {
    const response = await request.get(`${CONFIG.BACKOFFICE_API_URL}/discountCode?variant=value|freeDelivery|percent`,
      {
        headers: this.headers,
      }
    );
    const discounts = await response.json();
    const activeDiscount = JSON.stringify(discounts.filter((discount: any) => discount.status === 'active' && 'percent'));
    return discounts;
  }
  async getClient(request: APIRequestContext) {
    const response = await request.get(
      `${CONFIG.BACKOFFICE_API_URL}/client?${CONFIG.LOCATION_ID}`,
      {
        headers: this.headers,
      }
    );
    return await response.json();
  }
  async createSection(request: APIRequestContext, sectionData: SectionAutomation) {
    const response = await request.post(
      `${CONFIG.BACKOFFICE_API_URL}/restaurant/${CONFIG.RESTAURANT_ID}/brand-menu/${CONFIG.MENU_ID}/section`,
      {
        headers: this.headers,
        data: sectionData
      }
    );
    return await response.json();
  }

  async createProduct(request: APIRequestContext, productData: ProductAutomation) {
    const response = await request.post(`${CONFIG.BACKOFFICE_API_URL}/menu`, 
      {
      headers: this.headers,
      data: productData
    });
    return await response.json();
  }
  async createOption(request: APIRequestContext, optionData: OptionAutomation) {
    const response = await request.post(`${CONFIG.BACKOFFICE_API_URL}/optionGroup`, 
      {
      headers: this.headers,
      data: optionData
    });
    return await response.json();
  }
  async createAtomicOption(request: APIRequestContext, AtomicOptionData: AtomicOptionAutomation) {
    const response = await request.post(`${CONFIG.BACKOFFICE_API_URL}/atomicOption`, 
      {
      headers: this.headers,
      data: AtomicOptionData
    });
    return await response.json();
  }
  async createOrder(orderData: newOrderData) {

    //const stringifiedData = JSON.stringify(orderData);
    const response = await fetch(`${CONFIG.WEBSTORE_API_URL}/sendOrder`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(orderData),
    });
    return response.json();
    //const responseData = await response.json();
    //return responseData;
  }
  async createA(accountData: AccountAutomation) {
    const response = await fetch(`${CONFIG.BACKOFFICE_API_URL}/monoRestaurant`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(accountData),
    });
    return response.json();
    //const responseData = await response.json();
    //return responseData;
  }

  async deleteProduct(request: APIRequestContext, optionGroupId: string) {
    try {
      const response = await request.delete(`${CONFIG.BACKOFFICE_API_URL}/optionGroup/${optionGroupId}`, {
        headers: this.headers
      });
      return response.status();
    } catch (error) {
      console.error(`Error deleting product ${optionGroupId}:`, error);
      return null;
    }
  }

  async deleteSection(request: APIRequestContext, sectionId: string) {
    try {
      const response = await request.delete(
        `${CONFIG.BACKOFFICE_API_URL}/restaurant/${CONFIG.RESTAURANT_ID}/brand-menu/${CONFIG.MENU_ID}/section/${sectionId}`,
        {
          headers: this.headers
        }
      );
      return response.status();
    } catch (error) {
      console.error(`Error deleting section ${sectionId}:`, error);
      return null;
    }
  }
  async deleteOption(request: APIRequestContext, optionGroupId: string) {
    try {
      const response = await request.delete(
        `${CONFIG.BACKOFFICE_API_URL}/optionGroup/${optionGroupId}`,
        {
          headers: this.headers
        }
      );
      return response.status();
    } catch (error) {
      console.error(`Error deleting section ${optionGroupId}:`, error);
      return null;
    }
  }
  async acceptOrder(Order) {

    //const stringifiedData = JSON.stringify(orderData);
    const response = await fetch(`${CONFIG.BACKOFFICE_API_URL}/order/AcceptOrder`, {
      method: 'POST',
      headers: this.headers,
      body: Order.response
    });
    return response.json();
    //const responseData = await response.json();
    //return responseData;
  }
  async getOrders(request: APIRequestContext, o) {
    try {
      const orderCollection = await request.get(`${CONFIG.BACKOFFICE_API_URL}/order/?state=matched|preparation&deliveryOption=delivery&storeLocationId=${CONFIG.LOCATION_ID}`, {
        headers: this.headers
      });
      const orders = orderCollection.json();
      return orders;
    } catch (error) {
      console.error(`Error getting product `, error);
      return null;
    }
  }
  async getOrderById(request: APIRequestContext, orderId) {
    try {
      const orderCollection = await request.get(`${CONFIG.BACKOFFICE_API_URL}/order/${orderId}`, {
        headers: this.headers
      });
      const orders = orderCollection.json();
      return orders;
    } catch (error) {
      console.error(`Error getting product `, error);
      return null;
    }
  }
}