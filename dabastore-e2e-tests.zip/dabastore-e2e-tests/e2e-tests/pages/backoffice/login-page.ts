import { Page } from '@playwright/test';
import { CONFIG } from '../../config/environments';

export class BackofficeLoginPage {
  constructor(private page: Page) {}

  async navigateToBackoffice() {
    await this.page.goto(`${CONFIG.BACKOFFICE_URL}/#/login`);
  }

  async login(phone: string, password: string, step: 'both' | 'phone' | 'password' = 'both') {
    try {
      if (step === 'both' || step === 'phone') {
        // Enter phone number
        await this.page.getByRole('textbox', { name: 'Numéro de téléphone *' }).click();
        await this.page.getByRole('textbox', { name: 'Numéro de téléphone *' }).fill(phone);
        await this.page.getByTestId('sign-in-btn').click();
        
        if (step === 'phone') {
          return this.page;
        }
      }
      
      await this.page.getByRole('textbox', { name: 'Mot de passe *' }).click();
      await this.page.getByRole('textbox', { name: 'Mot de passe *' }).fill(password);
      await this.page.getByTestId('sign-in-btn').click();
      
      return this.page;
    } catch (error) {
      console.error(`Login attempt failed: ${error}`);
      return this.page;
    }
  }
}