import { Page } from '@playwright/test';
import { CONFIG } from '../../config/environments';

export class BackofficeActionsPage {
  constructor(private page: Page) {}

  async navigateToBackoffice() {
    await this.page.goto(`${CONFIG.BACKOFFICE_URL}/#/login`);
  }

  async login(phone: string, password: string, step: 'both' | 'phone' | 'password' = 'both') {
    try {
      if (step === 'both' || step === 'phone') {
        // Enter phone number
        await this.page.getByRole('textbox', { name: 'Numéro de téléphone *' }).click();
        await this.page.getByRole('textbox', { name: 'Numéro de téléphone *' }).fill(phone);
        await this.page.getByTestId('sign-in-btn').click();
        
        if (step === 'phone') {
          return this.page;
        }
      }
      
      await this.page.getByRole('textbox', { name: 'Mot de passe *' }).click();
      await this.page.getByRole('textbox', { name: 'Mot de passe *' }).fill(password);
      await this.page.getByTestId('sign-in-btn').click();
      
      return this.page;
    } catch (error) {
      console.error(`Login attempt failed: ${error}`);
      return this.page;
    }
  } 
  async acceptNewOrders() {
    await this.page.getByTestId('Accept').click();

  }
  async rejectNewOrders() {
    // Accept terms if prompted
    try {
      await this.page.getByTestId('Reject').click();
      await this.page.getByRole('button', { name: 'Confirmer' });
    } catch (error) {
      console.log('Reject button not found, continuing...');
    }
    //await this.page.getByTestId('order').click();
  }

  async navigateToAcceptOrders() {
    await this.page.getByTestId(`order`).click();
    await this.page.getByRole('tab', { name: 'Acceptée' }).click();
  }
  async navigateToRejectOrders() {
    await this.page.getByTestId('Reject').click();
  }

  async assignOrderToDriver(orderId: string, price:number) {
      await this.page.getByRole('row', { name: `${orderId}` + ` Acceptée` + ` ${price}` + ` MAD` }).getByRole('checkbox').click();
      await this.page.getByRole('button', { name: 'Assigner un livreur' }).click();
      await this.page.getByRole('cell', { name: 'zidan' }).first().click();
      await this.page.getByRole('button', { name: 'Attribuer' }).click();

  }

  async navigateToInProgressOrders() {
    await this.page.getByRole('tab', { name: 'En cours de livraison' }).click();
  }

  async openOrderDetails(orderId: string) {
    try {
      //await this.page.getByRole('row', { name: `${orderId} Delivery started 55.` }).getByRole('checkbox').check();
      await this.page.getByRole('link', { name: orderId, exact: true }).click();
    } catch (error) {
      console.error('Error while opening order details:', error);
      console.log('Continuing with test...');
    }
  }

  async updateOrderStatus(status: string) {
    try {
      await this.page.locator('div:nth-child(24) > button').first().click();
      await this.page.getByRole('button', { name: 'Status' }).click();
      await this.page.getByRole('option', { name: status }).click();
      await this.page.getByRole('button', { name: 'Confirmer', exact: true }).click();

    } catch (error) {
      console.error('Error while updating order status:', error);
      console.log('Continuing with test...');
    }
  }
  async creatediscountCode(code: string, discoountType: string) {
    try {
      await this.page.getByTestId('discount').click();
      await this.page.getByTestId('CreateButton').click();
      //await this.page.getByRole('button', { name: 'Vider le champ' }).click();
      await this.page.getByRole('textbox', { name: 'Code *' }).click();
      await this.page.getByRole('textbox', { name: 'Code *' }).fill('testdicount');
      await this.page.getByRole('button', { name: 'Variant * Livraison gratuite' }).click();
      await this.page.getByRole('option', { name: 'Livraison gratuite' }).click();
      await this.page.getByRole('radio', { name: 'Aucune limite (Annulation' }).check();
      await this.page.getByTestId('SaveButton').click();
      await this.page.getByText('testdicount').click();
      await this.page.getByRole('checkbox', { name: 'primary checkbox' }).uncheck();
    } catch (error) {
      console.error('Error while updating order status:', error);
      console.log('Continuing with test...');
    }
  }
  async createMarketingNotif(status: string) {
    try {
      await this.page.getByTestId('notifications').click();
      await this.page.getByTestId('CreateButton').click();
      await this.page.getByRole('textbox', { name: 'Titre de la notification Push' }).click();
      await this.page.getByRole('textbox', { name: 'Titre de la notification Push' }).fill('eid adha promo');
      await this.page.getByRole('button', { name: 'Mode d\'exécution Exécution' }).click();
      await this.page.getByRole('option', { name: 'Exécution immédiate' }).click();
      await this.page.getByRole('textbox', { name: 'Message de la notification' }).click();
      await this.page.getByRole('textbox', { name: 'Message de la notification' }).fill('happy eid');
      await this.page.getByTestId('SaveButton').click();
      await this.page.getByRole('cell', { name: 'Echouée' }).first().click();
    } catch (error) {
      console.error('Error while updating order status:', error);
      console.log('Continuing with test...');
    }
    //return status;
  }
}