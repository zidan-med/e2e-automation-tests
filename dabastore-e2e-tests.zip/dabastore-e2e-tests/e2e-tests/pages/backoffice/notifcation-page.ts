import { Page, Locator, expect } from '@playwright/test';
import { CONFIG } from '../../config/environments';

export class NotificationFormPage {
  readonly page: Page;
  readonly notificationOptions: Locator;

  readonly immediateOption: Locator;
  readonly deferredOption: Locator;
  readonly notificationTitleInput: Locator;
  
  readonly notificationMessageInput: Locator;
  readonly executionTimeInput: Locator;
  readonly timeConfirmation: Locator;
  readonly notificationSection: Locator;
  readonly createButton: Locator;
  readonly submitButton: Locator;
  readonly checkSuccessMessage: Locator;

  
  constructor(page: Page) {
    this.page = page;
    this.notificationSection = page.getByTestId('notifications');

    this.notificationOptions = page.getByRole('button', { name: 'Mode d\'exécution Exécution' });
    this.immediateOption = page.getByRole('option', { name: 'Exécution immédiate' });
    this.deferredOption = page.getByRole('option', { name: 'Exécution différée' });
    this.notificationTitleInput = page.getByRole('textbox', { name: 'Titre de la notification Push' });
    
    this.notificationMessageInput = page.getByRole('textbox', { name: 'Message de la notification' });
    this.executionTimeInput = page.getByRole('textbox').nth(1);
    this.timeConfirmation = page.getByRole('button', { name: 'OK' });

    
    this.submitButton = page.getByTestId('SaveButton');
    this.createButton = page.getByTestId('CreateButton');
    this.checkSuccessMessage = page.getByRole('alert' , { name: 'Notification créée' });

  }
  
  async navigateToNotificationSection() {
    //await this.page.goto('https://votre-site.com/admin/remises/creer-code-promo');
    await this.notificationSection.click();
  }
  async openNotificationForm() {
    //await this.page.goto('https://votre-site.com/admin/remises/creer-code-promo');
    await this.createButton.click();
  }
  
  async selectImmediateOption() {
    await this.notificationOptions.click();
    await this.immediateOption.click();
  }
  
  async selectDeferredOption() {
    await this.notificationOptions.click();
    await this.deferredOption.click();
  }
  
  
  async enterNotificationTitle(value: string) {
    await this.notificationTitleInput.click();
    await this.notificationTitleInput.fill(value);
  }
  
  
  async enterNotificationMessage(value: string) {
    await this.notificationMessageInput.click();

    await this.notificationMessageInput.fill(value);
  }
  
  async enterNotificationExuctiontime(value: string) {
    await this.executionTimeInput.click();
    //await this.notificationTitleInput.fill(value);
    await this.timeConfirmation.click();
  }
  
  async submitForm() {
    await this.submitButton.click();
  }
  
  async checkSuccess() {
    await this.checkSuccessMessage.check.name;
  }
  
  async createBasicNotification(options:{
    title: string;
    notificationType: 'deferred' | 'immediat' ;
    message: string; 
    excutionTime: string;
  }) {
    await this.enterNotificationTitle(options.title);
    
    switch (options.notificationType) {
      case 'immediat':
        //await this
        await this.selectImmediateOption();
        break;
      case 'deferred':
        await this.selectDeferredOption();
        await this.enterNotificationExuctiontime(options.excutionTime);
        break;
    }
    await this.enterNotificationMessage(options.message);
    await this.submitForm();
 
  
  }



  async checkNotificationResponse(page: Page) {
    // Listen for the response after calling the function
    page.on('response', async (response) => {
      if (response.url().includes(`${CONFIG.BACKOFFICE_URL}/notification`)) {
        // Log or inspect the response
        const jsonResponse = await response.json();
        console.log('Response from notification API:', jsonResponse);
  
        // If you want to check the status of the response
        if (response.status() === 200) {
          console.log('Notification was successfully created!');
        } else {
          console.log('Failed to create notification:', jsonResponse);
        }
      }
    });
    //return jsonResponse
  }

  
}
