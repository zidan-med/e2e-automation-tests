import { Page, Locator, expect } from '@playwright/test';

export class DiscountFormPage {
  readonly page: Page;
  readonly discountSection: Locator;
  readonly dicountOptions: Locator;

  readonly freeShippingOption: Locator;
  readonly percentageDiscountOption: Locator;
  readonly fixedValueDiscountOption: Locator;
  
  readonly promoCodeInput: Locator;
  readonly clearPromoCodeInput: Locator;
  readonly minOrderValueToggle: Locator;
  readonly minOrderValueInput: Locator;
  
  readonly percentageDiscountInput: Locator;
  readonly fixedValueDiscountInput: Locator;
  
  readonly noLimitOption: Locator;
  readonly expirationDateOption: Locator;
  readonly usageLimitOption: Locator;
  readonly expirationDateInput: Locator;
  readonly usageLimitInput: Locator;

  readonly createButton: Locator;

  readonly submitButton: Locator;

  readonly checkSuccessMessage: Locator;
  
  constructor(page: Page) {
    this.page = page;
    this.discountSection = page.getByTestId('discount');

    this.freeShippingOption = page.getByRole('option', { name: 'Livraison gratuite' });
    this.dicountOptions = page.getByRole('button', { name: 'Variant * Livraison gratuite' })
    this.percentageDiscountOption = page.getByRole('option', { name: 'Remise en pourcentage' });
    this.fixedValueDiscountOption = page.getByRole('option', { name: 'Remise à valeur fixe' });
    
    this.promoCodeInput = page.getByRole('textbox', { name: 'Code *' });
    this.clearPromoCodeInput = page.getByRole('button', { name: 'Vider le champ' });

    this.minOrderValueToggle = page.getByRole('checkbox', { name: 'Une valeur minimale de' });
    this.minOrderValueInput = page.getByRole('spinbutton', { name: 'Montant minimal de commande (' });
    
    this.percentageDiscountInput = page.getByRole('spinbutton', { name: 'Remise du code promo (en %) *' });
    this.fixedValueDiscountInput = page.getByRole('spinbutton', { name: 'Remise du code promo (en MAD' });
    
    this.noLimitOption = page.getByRole('radio', { name: 'Aucune limite (Annulation' });
    this.expirationDateOption = page.getByRole('radio', { name: 'Date d\'expiration' });
    this.usageLimitOption = page.getByRole('radio', { name: 'Limiter le nombre global d\'' });
    this.expirationDateInput = page.getByRole('textbox').nth(1);
    this.usageLimitInput = page.getByRole('spinbutton', { name: 'Limite' });
    
    this.submitButton = page.getByTestId('SaveButton');
    this.createButton = page.getByTestId('CreateButton');
    this.checkSuccessMessage = page.getByRole('alert' , { name: 'Code promo créé' });

  }
  
  async navigateToDiscountsection() {
    //await this.page.goto('https://votre-site.com/admin/remises/creer-code-promo');
    await this.discountSection.click();
  }
  async openDiscountForm() {
    //await this.page.goto('https://votre-site.com/admin/remises/creer-code-promo');
    await this.createButton.click();
  }
  
  async selectFreeShippingOption() {
    await this.dicountOptions.click();
    await this.freeShippingOption.click();
    await expect(this.freeShippingOption).toBeVisible();
  }
  
  async selectPercentageDiscountOption() {
    await this.dicountOptions.click();
    await this.percentageDiscountOption.click();
    await expect(this.percentageDiscountInput).toBeVisible();
  }
  
  async selectFixedValueDiscountOption() {
    await this.dicountOptions.click();
    await this.fixedValueDiscountOption.click();
    await expect(this.fixedValueDiscountInput).toBeVisible();
  }
  
  async enterPromoCode(code: string) {
    await this.clearPromoCodeInput.click();
    await this.promoCodeInput.fill(code);
  }
  
  async setMinimumOrderValue(value: string) {
    // Si le toggle n'est pas activé, l'activer
    const isToggled = await this.minOrderValueToggle.isChecked().catch(() => false);
    if (!isToggled) {
      await this.minOrderValueToggle.click();
    }
    await this.minOrderValueInput.fill(value);
  }
  
  async enterPercentageDiscount(percentage: string) {
    await this.percentageDiscountInput.fill(percentage);
  }
  
  async enterFixedValueDiscount(amount: string) {
    await this.fixedValueDiscountInput.fill(amount);
  }
  
  async selectNoLimit() {
    await this.noLimitOption.click();
  }
  
  async selectExpirationDate(date: string) {
    await this.expirationDateOption.click();
    await this.expirationDateInput.fill(date);
  }
  
  async selectUsageLimit(limit: string) {
    await this.usageLimitOption.click();
    await this.usageLimitInput.fill(limit);
  }
  
  async submitForm() {
    await this.submitButton.click();
  }
  
  async checkDiscountSuccess() {
    await this.checkSuccessMessage.check.name;
  }
  
  async createBasicPromoCode(options:{
    code: string;
    discountType: 'free-shipping' | 'percentage' | 'fixed-value';
    value?: string; 
    minOrderValue?: string;
    limitType?: 'no-limit' | 'expiration-date' | 'usage-limit';
    limitValue?: string; 
  }) {
    //await this.enterPromoCode(options.code);
    
    switch (options.discountType) {
      case 'free-shipping':
        //await this
        await this.selectFreeShippingOption();
        break;
      case 'percentage':
        await this.selectPercentageDiscountOption();
        await this.enterPercentageDiscount(options.value || '10');
        break;
      case 'fixed-value':
        await this.selectFixedValueDiscountOption();
        await this.enterFixedValueDiscount(options.value || '50');
        break;
    }
    
    if (options.minOrderValue) {
      await this.setMinimumOrderValue(options.minOrderValue);
    }
    
    if (options.limitType && options.limitValue) {
      switch (options.limitType) {
        case 'no-limit':
          await this.selectNoLimit();
          break;
        case 'expiration-date':
          await this.selectExpirationDate(options.limitValue);
          break;
        case 'usage-limit':
          await this.selectUsageLimit(options.limitValue);
          break;
      }
    } else {
      await this.selectNoLimit();
    }
    
    //await this.submitForm();
  }
}
