// pages/webstore/order-confirmation-page.ts
import { Page, Locator, expect } from '@playwright/test';
import { CONFIG } from '../../config/environments';

export class OrderConfirmationPage {
  readonly page: Page;
  
  // Locators
  readonly statusStepValidated: Locator;
  readonly statusStepPreparation: Locator;
  readonly statusStepPickedUp: Locator;
  readonly statusStepArrived: Locator;
  readonly orderNumberText: Locator;
  readonly orderSummaryTitle: Locator;
  readonly productName: (name: string) => Locator;
  readonly productQuantity: (name: string) => Locator;
  readonly subtotalAmount: Locator;
  readonly promoAmount: Locator;
  readonly deliveryFeeAmount: Locator;
  readonly tipAmount: Locator;
  readonly totalAmount: Locator;
  readonly cancelOrderButton: Locator;
  readonly notificationToggle: Locator;
  readonly paymentIcon: Locator;
  readonly toastCloseButton: Locator;
  readonly SuccessOutlinedIcon: Locator;
  readonly dabaStoreLogo: Locator;
  readonly payzoneLogo: Locator;

  constructor(page: Page) {
    this.page = page;
    
    // Initialize locators
    this.paymentIcon = page.getByTestId('PaymentIcon');
    this.toastCloseButton = page.getByRole('button', { name: 'Close' });
    this.SuccessOutlinedIcon = page.getByTestId('SuccessOutlinedIcon');
    this.dabaStoreLogo = page.locator('a').first();
    this.payzoneLogo = page.getByRole('img', { name: 'Payzone' });


    this.statusStepValidated = page.locator('text=Validé');
    this.statusStepPreparation = page.locator('text=Préparation');
    this.statusStepPickedUp = page.locator('text=Ramassé');
    this.statusStepArrived = page.locator('text=Arrivée');
    this.orderNumberText = page.locator('Numéro de la commande:');
    this.orderSummaryTitle = page.locator('text=Récapitulatif de votre commande');
    this.productName = (name: string) => page.getByRole('heading', { name: name })
    //this.productQuantity = (name: string) => page.getByText('1x').getByText(name);
    this.subtotalAmount = page.getByText('Sous-total').locator('xpath=..');
    this.promoAmount = page.getByText('Promo').locator('xpath=..')
    this.deliveryFeeAmount = page.getByText('Frais de livraison').locator('xpath=..')
    this.tipAmount = page.getByText('Pourboire').locator('xpath=..')
    this.totalAmount = page.getByText('Total', { exact: true }).locator('xpath=..')
    this.cancelOrderButton = page.getByRole('button', { name: 'Annuler la commande' });
    this.notificationToggle = page.locator('input[type="checkbox"]').getByText('Recevez des notifications');
  }
  
  // Navigation method 
  async navigateToOrderPage(storeId: string, orderId: string) {
    //const baseUrl = process.env.BASE_URL || 'https://your-default-url.com';
    await this.page.goto(`${CONFIG.BASE_URL}/webstore/${storeId}/order/${orderId}`);
    await this.page.waitForLoadState('networkidle');
  }
  
  // Helper methods to verify UI elements
  async verifyOrderStatusDisplayDelivery() {
    await expect(this.statusStepValidated).toBeVisible();
    await expect(this.statusStepPreparation).toBeVisible();
    await expect(this.statusStepPickedUp).toBeVisible();
    await expect(this.statusStepArrived).toBeVisible();
  }
  async verifyOrderStatusDisplayPickup() {
    await expect(this.statusStepValidated).toBeVisible();
    await expect(this.statusStepPreparation).toBeVisible();
    await expect(this.statusStepPickedUp).toBeVisible();
  }
  async verifyPaymentIcon() {
    await expect(this.paymentIcon).toBeVisible();
  }
  
  async verifyOrderNumber(orderId: string, page) {
    await expect(page.getByText(this.orderNumberText  + ` ${orderId}`)).toBeVisible();
  }
  //await expect(page.getByText('Numéro de la commande:' + ` ${orderId}`)).toBeVisible();

  async verifyDabaStoreLogo() {
    await expect(this.dabaStoreLogo).toBeVisible();
  }
  async verifytoastCloseButton() {
    await expect(this.toastCloseButton).toBeVisible();
  }
  async verifyPayzoneLogo() {
    await expect(this.payzoneLogo).toBeVisible();
  }
  async verifyOrderSummary() {
    await expect(this.orderSummaryTitle).toBeVisible();
  }
  async verifySuccessOutlinedIcon() {
    await expect(this.SuccessOutlinedIcon).toBeVisible();
  }
  
  
  async verifyProductDetails(productName: string) {
    await expect(this.productName(productName)).toBeVisible();
    //await expect(this.productQuantity(productName)).toBeVisible();
  }
  
  async verifyOrdersubtotalAmount(subtotal: number) {
    //await expect(this.subtotalAmount).toContainText(`${subtotal} MAD`);
    const formattedSubtotal = String(subtotal).replace('.', ',');
    await expect(this.subtotalAmount).toContainText(`${formattedSubtotal} MAD`);
  }
  
  async verifyOrderpromoAmount(promo: string) {
    const formattedPromo = String(promo).replace('.', ',');
    await expect(this.promoAmount).toContainText(`${formattedPromo} MAD`);
  }
  async verifyOrderdeliveryFeeAmount(deliveryFeeAmount: string) {
    const formattedDeliveryFee = String(deliveryFeeAmount).replace('.', ',');
    await expect(this.deliveryFeeAmount).toContainText(`${formattedDeliveryFee} MAD`);
  }
  async verifyOrdertipAmount(tipAmount: string) {
    const formattedTip = String(tipAmount).replace('.', ',');
    await expect(this.tipAmount).toContainText(`${formattedTip} MAD`);
    //await expect(page.locator('.line')).toContainText([, '99,99 MAD']);

  }
  async verifyOrdertotalAmount(totalAmount: string) {
    const formattedTotal = String(totalAmount).replace('.', ',');
    await expect(this.totalAmount).toContainText(`${formattedTotal} MAD`);
  }
  

  
  async toggleNotifications(setEnabled: boolean) {
    const isChecked = await this.notificationToggle.isChecked();
    if ((setEnabled && !isChecked) || (!setEnabled && isChecked)) {
      await this.notificationToggle.click();
    }
  }
  

  async verifyCancelOrderButton() {
    await expect(this.cancelOrderButton).toBeEnabled();
  }

  async verifyOrderStatusUpdateDelivery(currentStep = 'Validé') {
    // First verify all steps are visible
    await expect(this.statusStepValidated).toBeVisible();
    await expect(this.statusStepPreparation).toBeVisible();
    await expect(this.statusStepPickedUp).toBeVisible();
    await expect(this.statusStepArrived).toBeVisible();
    
    // Define steps in order
    const steps = ['Validé', 'Préparation', 'Ramassé', 'Arrivée'];
    const currentIndex = steps.indexOf(currentStep);
    
    if (currentIndex === -1) {
      throw new Error(`Invalid step name: ${currentStep}`);
    }
    
    // Map step names to their corresponding selectors
    const stepSelectors = {
      'Validé': this.statusStepValidated,
      'Préparation': this.statusStepPreparation,
      'Ramassé': this.statusStepPickedUp,
      'Arrivée': this.statusStepArrived
    };
    
    // Check each step's state
    for (let i = 0; i < steps.length; i++) {
      const stepName = steps[i];
      const stepElement = stepSelectors[stepName];
      
      if (i < currentIndex) {
        // Completed steps should have a checkmark
        await expect(this.page.locator('[data-testid="CheckIcon"]')).toBeVisible();
        // Adjust the selector based on your actual checkmark implementation
      } else if (i === currentIndex) {
        // Current step should have the active indicator/circle
        await expect(stepElement.locator('[data-testid="CheckIcon"]')).not.toBeVisible();
        // Adjust the selector based on your actual active indicator implementation
      } else {
        // Future steps should be inactive (no checkmark, no active indicator)
        await expect(stepElement.locator('[data-testid="CheckIcon"]')).not.toBeVisible({timeout: 1000});
        await expect(stepElement.locator('[data-testid="CheckIcon"]')).not.toBeVisible({timeout: 1000});
      }
    }
    
    // Verify progress bar width based on current step
    // The progress appears to fill between steps, so we can use formula: currentIndex / (totalSteps - 1)
    // For example, at Préparation (index 1), it would be 1/3 = 33% full
    //const progressPercentage = currentIndex === steps.length - 1 ? 100 : (currentIndex / (steps.length - 1)) * 100;
    
    // Based on your implementation, check progress bar
    // Option 1: If it's a styled element with width
    //await expect(this.progressBar).toHaveAttribute('style', new RegExp(`width: ${progressPercentage}%`));
    // Or Option 2: If it's a colored background element
    // await expect(this.progressBar).toHaveCSS('width', `${progressPercentage}%`);
    
    // Finally, verify the order ID is correctly displayed
    //const orderIdText = await this.orderIdElement.textContent();
    //expect(orderIdText).toContain('ZUJES3LP'); // Or use a parameter instead of hardcoding
  }

  async verifyOrderStatusUpdatePickup(currentStep = 'Validé') {
    // First verify all steps are visible
    await expect(this.statusStepValidated).toBeVisible();
    await expect(this.statusStepPreparation).toBeVisible();
    await expect(this.statusStepPickedUp).toBeVisible();
    
    // Define steps in order
    const steps = ['Validé', 'Préparation', 'Ramassé'];
    const currentIndex = steps.indexOf(currentStep);
    
    if (currentIndex === -1) {
      throw new Error(`Invalid step name: ${currentStep}`);
    }
    
    // Map step names to their corresponding selectors
    const stepSelectors = {
      'Validé': this.statusStepValidated,
      'Préparation': this.statusStepPreparation,
      'Ramassé': this.statusStepPickedUp
    };
    
    // Check each step's state
    for (let i = 0; i < steps.length; i++) {
      const stepName = steps[i];
      const stepElement = stepSelectors[stepName];
      
      if (i < currentIndex) {
        // Completed steps should have a checkmark
        await expect(this.page.locator('[data-testid="CheckIcon"]')).toBeVisible();
        // Adjust the selector based on your actual checkmark implementation
      } else if (i === currentIndex) {
        // Current step should have the active indicator/circle
        await expect(stepElement.locator('[data-testid="CheckIcon"]')).not.toBeVisible();
        // Adjust the selector based on your actual active indicator implementation
      } else {
        // Future steps should be inactive (no checkmark, no active indicator)
        await expect(stepElement.locator('[data-testid="CheckIcon"]')).not.toBeVisible({timeout: 1000});
        await expect(stepElement.locator('[data-testid="CheckIcon"]')).not.toBeVisible({timeout: 1000});
      }
    }
    
    // Verify progress bar width based on current step
    // The progress appears to fill between steps, so we can use formula: currentIndex / (totalSteps - 1)
    // For example, at Préparation (index 1), it would be 1/3 = 33% full
    //const progressPercentage = currentIndex === steps.length - 1 ? 100 : (currentIndex / (steps.length - 1)) * 100;
    
    // Based on your implementation, check progress bar
    // Option 1: If it's a styled element with width
    //await expect(this.progressBar).toHaveAttribute('style', new RegExp(`width: ${progressPercentage}%`));
    // Or Option 2: If it's a colored background element
    // await expect(this.progressBar).toHaveCSS('width', `${progressPercentage}%`);
    
    // Finally, verify the order ID is correctly displayed
    //const orderIdText = await this.orderIdElement.textContent();
    //expect(orderIdText).toContain('ZUJES3LP'); // Or use a parameter instead of hardcoding
  }
}