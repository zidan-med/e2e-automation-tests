import { Page } from '@playwright/test';
import { CustomerData } from '../../models/types';
import { CreditCardDetail } from '../../models/types';

import { CONFIG } from '../../config/environments';

export class WebstorePage {
  constructor(private page: Page) {}
  
  async navigateToWebstore(menuId: string) {
    await this.page.goto(`${CONFIG.BASE_URL}/webstore/qa3333?webstoretemplate=default&?menuID=${menuId}`);
  }

  async selectSection(sectionName: string) {
    await this.page.getByRole('link', { name: sectionName }).click();
  }

  async selectProduct(productName: string) {
    await this.page.getByRole('heading', { name: productName }).click();
  }

  async addToCart() {
    await this.page.getByRole('button', { name: /Ajouter pour/ }).click();
  }

  async proceedToCheckout() {
    await this.page.getByRole('link', { name: 'Commander' }).click();
  }

  async fillCheckoutDeliveryForm(customerData: CustomerData) {
    await this.page.getByLabel('Nom *').click();
    await this.page.getByLabel('Nom *').fill(customerData.name);
    await this.page.getByPlaceholder('0650123456').click();
    await this.page.getByPlaceholder('0650123456').fill(customerData.phoneNumber);
    //await this.page.getByPlaceholder('0650123456').fill(customerData.phoneNumber);
    await this.page.getByLabel('Email').click();
    await this.page.getByLabel('Email').fill(customerData.email);
    
    // Click on the map to set delivery address
    await this.page.locator('div').filter({ hasText: /^Adresse de livraison\*\+− Leaflet×$/ }).locator('path').nth(1).click();
    
    await this.page.getByRole('textbox', { name: 'Demandes spéciales' }).fill(customerData.specialRequest);
    await this.page.locator('button[type="submit"]').scrollIntoViewIfNeeded();
  }

  async fillCheckoutPickupForm(customerData: CustomerData) {
    await this.page.getByText('À emporter').click();
    await this.page.getByLabel('Nom *').click();
    await this.page.getByLabel('Nom *').fill(customerData.name);
    await this.page.getByPlaceholder('0650123456').click();
    await this.page.getByPlaceholder('0650123456').fill(customerData.phoneNumber);
    //await this.page.getByPlaceholder('0650123456').fill(customerData.phoneNumber);
    await this.page.getByLabel('Email').click();
    await this.page.getByLabel('Email').fill(customerData.email);
   // await this.selectPaymentOption(Option);
    
    // Click on the map to set delivery address
    //await this.page.locator('div').filter({ hasText: /^Adresse de livraison\*\+− Leaflet×$/ }).locator('path').nth(1).click();
    
    await this.page.getByRole('textbox', { name: 'Demandes spéciales' }).fill(customerData.specialRequest);
    await this.page.locator('button[type="submit"]').scrollIntoViewIfNeeded();
  }


  async selectPaymentOption(option: 'cash' | 'online' | 'tpe', cardDetails: CreditCardDetail = {}) {
    // First click to open the dropdown
    await this.page.getByRole('button', { name: 'Mode de paiement Paiement en' }).click();
    
    // Select the specified payment option
    switch (option) {
      case 'cash':
        await this.page.getByRole('option', { name: 'Paiement en espèces à la' }).click();
        break;
        
      case 'online':
        await this.page.getByRole('option', { name: 'Paiement en ligne' }).click();
        // Handle card information fields
        await this.fillCardInformation(cardDetails);
        break;
        
      case 'tpe':
        await this.page.getByRole('option', { name: 'Paiement par TPE à la' }).click();
        break;
        
      default:
        const exhaustiveCheck: never = option;
        throw new Error(`Payment option "${option}" not supported`);
    }
  }
  async addValidDiscountCode(discountCode: string) {
    await this.page.getByPlaceholder('Ajouter un code de réduction').click();
    await this.page.getByPlaceholder('Ajouter un code de réduction').fill(discountCode);
  }
  async validateDiscountCode() {
    await this.page.getByRole('button', { name: 'Ajouter' }).click();
  }
  async fillCardInformation(cardDetails: CreditCardDetail = {}) {
    const number = cardDetails.number || '4111111111111111';
    const name = cardDetails.name || 'Test User';
    const expiry = cardDetails.expiry || '12/25';
    const cvv = cardDetails.cvv || '123';
    
    // Wait for card form to appear (you might need to adjust the selector)
    await this.page.waitForSelector('.card-form', { timeout: 5000 });
    
    // Fill card details
    await this.page.getByLabel('Numéro de carte').fill(number);
    await this.page.getByLabel('Nom du titulaire').fill(name);
    await this.page.getByLabel('Date d\'expiration').fill(expiry);
    await this.page.getByLabel('Code de sécurité').fill(cvv);
    
    // Submit card information (adjust selector as needed)
    await this.page.getByRole('button', { name: 'Confirmer le paiement' }).click();
    
    // Wait for processing (optional)
    await this.page.waitForSelector('.payment-confirmation', { timeout: 10000 }).catch(() => {
      console.log('Payment confirmation element not found within timeout');
    });
  }
  async submitOrder() {
    await this.page.locator('button[type="submit"]').scrollIntoViewIfNeeded();
    await this.page.locator('button[type="submit"]').click();
    
    // Wait for navigation to complete
    try {
      await this.page.waitForNavigation({ timeout: 30000 });
    } catch (error) {
      console.log('Navigation may have completed already or timed out');
    }
  } 

}