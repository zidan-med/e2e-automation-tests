// In a new file: e2e-tests/test-data/restaurant-test-data.ts
import { APIRequestContext } from '@playwright/test';
import { TestDataGenerator } from '../../utils/test-data-generator';
import { ApiHelper } from '../../helpers/api-helper';
import { CONFIG } from '../../config/environments';
import { CustomerData } from '../../models/types';

export class RestaurantTestData {
  private apiHelper: ApiHelper;
  private request: APIRequestContext;
  
  // Data properties
  public section: { name: any; id: string };
  public product: { name: any; id: string };
  public option: any;
  public atomicOption: any;
  public discounts: { code: any }[];
  public customerData: CustomerData;
  public accountData: any;
  public accountResponse: any;

  constructor(request: APIRequestContext, apiHelper: ApiHelper) {
    this.request = request;
    this.apiHelper = apiHelper;
  }

  /**
   * Initialize and create all test data needed for restaurant tests
   */
  async initialize(): Promise<void> {
    // Generate customer data
    this.customerData = TestDataGenerator.generateCustomerData();
    this.accountData = TestDataGenerator.generatAccountData();
    
    // Create account
    this.accountResponse = await this.apiHelper.createAccount(this.request,this.accountData);
    
    // Create restaurant data (menu, sections, products)

    
    console.log(`Test data initialization complete with section: ${this.accountResponse}`);
  }

  /**
   * Clean up all created test data
   */
  async cleanup(): Promise<void> {
    if (this.product?.id) {
      await this.apiHelper.deleteProduct(this.request, this.product.id);
      console.log(`Deleted product: ${this.product.id}`);
    }
    
    if (this.section?.id) {
      await this.apiHelper.deleteSection(this.request, this.section.id);
      console.log(`Deleted section: ${this.section.id}`);
    }
    
    // Add any additional cleanup needed
  }
}