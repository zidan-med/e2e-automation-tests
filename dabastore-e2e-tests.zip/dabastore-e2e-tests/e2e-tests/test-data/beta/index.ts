import { ITestData } from "../types";

const betaTestData: ITestData = {
    monoRestaurant: {
        name: "QA",
        webstoreId: "qa3333",
        managerPhoneNumber: "+212648588997",
        driverPhoneNumber: "+212604309862",
        restaurantId: "1L4JRAVV"
    },
    baseUrl: "https://beta.daba.store"
}
export default betaTestData;