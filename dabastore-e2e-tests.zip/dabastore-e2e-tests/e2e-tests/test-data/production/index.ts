import { ITestData } from "../types";

const productionTestData: ITestData = {
    monoRestaurant: {
        name: "Mio ristorante",
        webstoreId: "mio-webstor",
        managerPhoneNumber: "+21267729105",
        driverPhoneNumber: "+212604309862",
        restaurantId: "F88YHRE9"
    },
    baseUrl: "https://daba.store"

}
export default productionTestData;