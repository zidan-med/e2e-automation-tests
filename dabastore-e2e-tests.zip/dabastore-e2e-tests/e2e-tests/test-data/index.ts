import { ITestData } from "./types";
import betaTestData from "./beta";
import productionTestData from "./production";
const environment = process.env.TEST_ENV || 'beta';

const environmentData: ITestData =
    environment === 'beta' ? betaTestData : productionTestData
    ;

export default environmentData;