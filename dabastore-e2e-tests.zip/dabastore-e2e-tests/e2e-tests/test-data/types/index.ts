
export interface IRestaurantTestData {
    name: string;
    webstoreId: string;
    managerPhoneNumber: string;
    driverPhoneNumber: string,
    restaurantId: string;
}
export interface ITestData {
    monoRestaurant: IRestaurantTestData,
    baseUrl: string;
}