
import { APIRequestContext } from '@playwright/test';
import { ApiHelper } from '../helpers/api-helper';
import { AuthHelper } from '../helpers/auth-helper';
import { TestDataGenerator } from '../utils/test-data-generator';

export interface ApiHelperFixture {
  apiHelper: ApiHelper | null;
  init(request: APIRequestContext): Promise<void>;
  createTestData(request: APIRequestContext, restaurantId: string, menuId: string): Promise<{
    section: any;
    //account: any;
    product: any;
    discounts: any[];
  }>;
  createAccountTestData(request: APIRequestContext): Promise<{
    account: any;
  }>;
  deleteProduct(request: APIRequestContext, productId: string): Promise<number | null>;
  deleteSection(request: APIRequestContext, sectionId: string): Promise<number | null>;
  deleteOption(request: APIRequestContext, optionGroupId: string): Promise<number | null>;

}

export async function createApiHelperFixture(): Promise<ApiHelperFixture> {
  return {
    apiHelper: null,

    async init(request: APIRequestContext) {
      const authHelper = new AuthHelper();
      const accountData = TestDataGenerator.generatAccountData();

      const responseBody1 = await authHelper.authStart(request, accountData.phone);
      const responseBody2 = await authHelper.authSetup(request, accountData.phone, responseBody1);

      const authToken = await authHelper.getToken(request, accountData.phone);
      this.apiHelper = new ApiHelper(authToken);
    },
    async createAccountTestData(request: APIRequestContext) {
      if (!this.apiHelper) await this.init(request);

      const accountData = TestDataGenerator.generatAccountData();
      const accountResponse = await this.apiHelper!.createAccount(request, accountData);

      return {
        account: accountResponse,
      };
    },
    async createTestData(request: APIRequestContext, restaurantId: string, menuId: string) {
      if (!this.apiHelper) await this.init(request);
      
      //const accountData = TestDataGenerator.generatAccountData();
      //const accountResponse = await this.apiHelper!.createAccount(request, accountData);
      const sectionData = TestDataGenerator.generateSectionData(restaurantId);
      const sectionResponse = await this.apiHelper!.createSection(request, sectionData);
      const optionData = TestDataGenerator.generateOptionData(menuId);
      const optionResponse = await this.apiHelper!.createOption(request, optionData);
      const atomicoptionData = TestDataGenerator.generateAtomicOptionData(optionResponse.id, menuId);
      const atomicoptionResponse = await this.apiHelper!.createAtomicOption(request, atomicoptionData);
      const productData = TestDataGenerator.generateProductData(sectionResponse.id, menuId, optionResponse.id);
      const productResponse = await this.apiHelper!.createProduct(request, productData);
      const discountCodeResponse = await this.apiHelper!.getDiscounts(request);


      return {
        //account: accountResponse,
        section: sectionResponse,
        product: productResponse,
        atomicOption: atomicoptionResponse,
        option: optionResponse,
        discounts: discountCodeResponse
      };
    },
    
    async deleteProduct(request: APIRequestContext, productId: string) {
      if (!this.apiHelper) await this.init(request);
      return await this.apiHelper!.deleteProduct(request, productId);
    },
    
    async deleteSection(request: APIRequestContext, sectionId: string) {
      if (!this.apiHelper) await this.init(request);
      return await this.apiHelper!.deleteSection(request, sectionId);
    },
        
    async deleteOption(request: APIRequestContext, optionGroupId: string) {
      if (!this.apiHelper) await this.init(request);
      return await this.apiHelper!.deleteOption(request, optionGroupId);
    }
  };
}