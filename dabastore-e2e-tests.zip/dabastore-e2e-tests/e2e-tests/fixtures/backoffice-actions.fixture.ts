import { Page } from '@playwright/test';
import { BackofficeActionsPage } from '../pages/backoffice/backoffice-page';

export interface BackofficeActionsFixture {
  actionsPage: BackofficeActionsPage;
  navigateToBackoffice(): Promise<void>;
  login(phone: string, password: string): Promise<void>;
  acceptNewOrders(): Promise<void>;
  navigateToAcceptOrders(): Promise<void>;
  assignOrderToDriver(orderId: string, orderTotal: number): Promise<void>;
  navigateToInProgressOrders(): Promise<void>;
  updateOrderStatus(status: string): Promise<void>;
  openOrderDetails(orderId: string): Promise<void>;

}

export async function createBackofficeActionsFixture(page: Page): Promise<BackofficeActionsFixture> {
  return {
    actionsPage: new BackofficeActionsPage(page),
    
    async navigateToBackoffice() {
      await this.actionsPage.navigateToBackoffice();
    },
    
    async login(phone: string, password: string) {
      await this.actionsPage.login(phone, password);
    },
    
    async acceptNewOrders() {
      await this.actionsPage.acceptNewOrders();
    },
    
    async navigateToAcceptOrders() {
      await this.actionsPage.navigateToAcceptOrders();
    },
    
    async assignOrderToDriver(orderId: string, orderTotal: number) {
      await this.actionsPage.assignOrderToDriver(orderId, orderTotal);
    },
    async navigateToInProgressOrders() {
      await this.actionsPage.navigateToInProgressOrders();
    },
    
    async updateOrderStatus(status: string) {
      await this.actionsPage.assignOrderToDriver(status);
    },
    async openOrderDetails(orderId: string) {
      await this.actionsPage.assignOrderToDriver(orderId);
    }


  };
}