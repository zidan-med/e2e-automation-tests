
import { Page } from '@playwright/test';
import { WebstorePage } from '../pages/webstore/webstore-page';
import { OrderConfirmationPage } from '../pages/webstore/order-confirmation-page';
import { CONFIG } from '../config/environments';

export interface WebstoreOrderingFixture {
  webstorePage: WebstorePage;
  orderConfirmationPage: OrderConfirmationPage;
  completeOrder(options: {
    menuId: string;
    sectionName: string;
    productName: string;
    customerData: any;
    paymentMethod: string;
    discountCode: string;
  }): Promise<any>;
  verifyOrderConfirmationDelivery(options: {
    orderId: string;
    productName: string;
    promo: number;
    subtotal: number;
    tip: number;
    deliveryFee: number;
    total: number;
  }): Promise<void>;
  verifyOrderConfirmationPickup(options: {
    orderId: string;
    productName: string;
    promo: number;
    subtotal: number;
    total: number;
  }): Promise<void>;
  verifyOrderStatusUpdateDelivery(expectedStatus: string): Promise<void>;
  verifyOrderStatusUpdatePickup(expectedStatus: string): Promise<void>;
  applyDicountCode(discountCode: string): Promise<void>;
  submitOrder(): Promise<void>;

}

export async function createWebstoreOrderingFixture(page: Page): Promise<WebstoreOrderingFixture> {
  return {
    webstorePage: new WebstorePage(page),
    orderConfirmationPage: new OrderConfirmationPage(page),
    
    async completeOrder({ menuId, sectionName, productName, customerData, paymentMethod, discountCode }) {
      await this.webstorePage.navigateToWebstore(menuId);
      await this.webstorePage.selectSection(sectionName);
      await this.webstorePage.selectProduct(productName);
      await this.webstorePage.addToCart();
      await this.webstorePage.proceedToCheckout();
      await this.webstorePage.fillCheckoutDeliveryForm(customerData);
      await this.webstorePage.selectPaymentOption(paymentMethod);
      await this.webstorePage.addValidDiscountCode(discountCode);
      await this.webstorePage.validateDiscountCode();
      
      const responsePromise = page.waitForResponse(response => 
        response.request().method() === 'POST' && 
        response.url().includes(`${CONFIG.WEBSTORE_API_URL}/sendOrder`));

      await this.webstorePage.submitOrder();
      const response = await responsePromise;
      const orderDetails = await response.json();
      
      await page.waitForURL(`${CONFIG.BASE_URL}/webstore/${CONFIG.STORE_ID}/order/${orderDetails.id}`, { timeout: 30000 });
      
      return orderDetails;
    },
    async submitOrder() {
      const responsePromise = page.waitForResponse(response => 
        response.request().method() === 'POST' && 
        response.url().includes(`${CONFIG.WEBSTORE_API_URL}/sendOrder`));

      await this.webstorePage.submitOrder();
      const response = await responsePromise;
      const orderDetails = await response.json();
      
      await page.waitForURL(`${CONFIG.BASE_URL}/webstore/${CONFIG.STORE_ID}/order/${orderDetails.id}`, { timeout: 30000 });
      
      return orderDetails;
    },
    async applyDicountCode(discountCode) {
      await this.webstorePage.addValidDiscountCode(discountCode);
      await this.webstorePage.validateDiscountCode();
    },
    async verifyOrderConfirmationDelivery({ orderId, productName, promo, subtotal, tip, deliveryFee, total }) {
      await this.orderConfirmationPage.verifyOrderStatusDisplayPickup();
      await this.orderConfirmationPage.verifyOrderNumber(orderId, page);
      await this.orderConfirmationPage.verifyOrderSummary();
      await this.orderConfirmationPage.verifyProductDetails(productName);
      await this.orderConfirmationPage.verifyCancelOrderButton();
      await this.orderConfirmationPage.verifyOrderpromoAmount(promo);
      await this.orderConfirmationPage.verifyOrdersubtotalAmount(subtotal);
      await this.orderConfirmationPage.verifyOrdertipAmount(tip);
      await this.orderConfirmationPage.verifyOrderdeliveryFeeAmount(deliveryFee);
      await this.orderConfirmationPage.verifyOrdertotalAmount(total);
    },
    async verifyOrderConfirmationPickup({ orderId, productName, promo, subtotal, total }) {
      await this.orderConfirmationPage.verifyOrderStatusDisplayDelivery();
      await this.orderConfirmationPage.verifyOrderNumber(orderId, page);
      await this.orderConfirmationPage.verifyOrderSummary();
      await this.orderConfirmationPage.verifyProductDetails(productName);
      await this.orderConfirmationPage.verifyCancelOrderButton();
      await this.orderConfirmationPage.verifyOrderpromoAmount(promo);
      await this.orderConfirmationPage.verifyOrdersubtotalAmount(subtotal);
      await this.orderConfirmationPage.verifyOrdertotalAmount(total);
    },
    async verifyOrderStatusUpdateDelivery(expectedStatus) {
      await this.orderConfirmationPage.verifyOrderStatusUpdateDelivery(expectedStatus);
    },
    async verifyOrderStatusUpdatePickup(expectedStatus) {
      await this.orderConfirmationPage.verifyOrderStatusUpdatePickup(expectedStatus);
    }
  };
}