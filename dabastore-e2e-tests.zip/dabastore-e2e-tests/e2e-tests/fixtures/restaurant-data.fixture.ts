// In file: e2e-tests/fixtures/restaurant-fixtures.ts
import { test as base } from '@playwright/test';
import { ApiHelper } from '../helpers/api-helper';
import { RestaurantTestData } from '/Users/mac/Downloads/dossier sans titre/dabastore-e2e-tests/e2e-tests/test-data/beta/restaurant-test-data.ts';
import { AuthHelper } from '../helpers/auth-helper';

// Define fixture type
type RestaurantFixtures = {
  restaurantData: RestaurantTestData;
};

// Extend the base test with our custom fixture
export const test = base.extend<RestaurantFixtures>({
  restaurantData: async ({ request }, use) => {
    // Create API helper
    const authHelper = new AuthHelper();
    const authToken = await authHelper.getToken(request);
    //const apiHelper = new ApiHelper(authToken);
    const apiHelper = new ApiHelper(authToken);
    
    // Create and initialize test data
    const testData = new RestaurantTestData(request, apiHelper);
    await testData.initialize();
    
    // Use the data in the test
    await use(testData);
    
    // Clean up after the test
    await testData.cleanup();
  }
});

export { expect } from '@playwright/test';