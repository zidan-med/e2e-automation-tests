import { APIRequestContext, test as base } from '@playwright/test';
import { default as testData } from "../test-data";
import SERVER_ENDPOINT from '../constants/server-endpoints';
const { baseUrl } = testData;

export const driverTest = base.extend<any>({
    phone: "",
    restaurantId: "",
    driverApi: async ({ request, playwright, phone, restaurantId }, use) => {
        const authRequest = await request.post(`${baseUrl}/${SERVER_ENDPOINT.DRIVER_LOGIN}`, {
            data: {
                phone: phone,
                authCodeTransport: "sms",
                code: "0000",
                restaurantId: restaurantId,
            }
        });
        const authToken = (await authRequest.json()).authToken;
        const apiContext = await playwright.request.newContext({
            // All requests we send go to this API endpoint.
            baseURL: `${baseUrl}/api`,
            extraHTTPHeaders: {
                'Content-Type': 'application/json',
                'x_access_token': authToken,
                'x-source': 'driver-app',
            },
        });
        await use(apiContext);
    },
});