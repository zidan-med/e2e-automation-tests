import { test as base } from '@playwright/test';
import { WebstoreOrderingFixture, createWebstoreOrderingFixture } from './webstore-ordering.fixture';
import { BackofficeActionsFixture, createBackofficeActionsFixture } from './backoffice-actions.fixture';
import { ApiHelperFixture, createApiHelperFixture } from './backoffice-api.fixtures';

// Define the combined fixtures type
export type TestFixtures = {
  webstoreOrdering: WebstoreOrderingFixture;
  backofficeActions: BackofficeActionsFixture;
  apiHelper: ApiHelperFixture;
};

// Create the base test with fixtures
export const test = base.extend<TestFixtures>({
  // WebStore ordering fixture
  webstoreOrdering: async ({ browser }, use) => {
    const customerContext = await browser.newContext();
    const customerPage = await customerContext.newPage();
    await customerPage.bringToFront();
    
    const fixture = await createWebstoreOrderingFixture(customerPage);
    
    await use(fixture);
    await customerContext.close();
  },
  
  // Backoffice actions fixture
  backofficeActions: async ({ browser }, use) => {
    const adminContext = await browser.newContext();
    const adminPage = await adminContext.newPage();
    
    const fixture = await createBackofficeActionsFixture(adminPage);
    
    await use(fixture);
    await adminContext.close();
  },
  
  // API helper fixture
  apiHelper: async ({ request }, use) => {
    const fixture = await createApiHelperFixture();
    
    // Initialize the API helper
    await fixture.init(request);
    
    await use(fixture);
  }
});

export { expect } from '@playwright/test';