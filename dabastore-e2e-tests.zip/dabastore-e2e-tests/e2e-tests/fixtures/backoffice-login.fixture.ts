import { test as base, Page } from '@playwright/test';
import { BackofficeLoginPage } from '../pages/backoffice/login-page';
import { CONFIG } from '../config/environments';

// Define the fixture interface
export interface BackofficeLoginFixture {
  loginPage: BackofficeLoginPage | null;
  init(page: Page): void;
  loginToBackoffice(phone?: string, password?: string): Promise<void>;
}

// Create and export the fixture
export const backofficeLoginFixture = base.extend<{ backofficeLogin: BackofficeLoginFixture }>({
  backofficeLogin: async ({}, use) => {
    const fixture: BackofficeLoginFixture = {
      loginPage: null,
      
      init(page: Page) {
        this.loginPage = new BackofficeLoginPage(page);
      },
      
      async loginToBackoffice(phone = CONFIG.CREDENTIALS.phone.substring(1), password = CONFIG.CREDENTIALS.password) {
        if (!this.loginPage) {
          throw new Error('Login page not initialized. Call init(page) first.');
        }
        await this.loginPage.navigateToBackoffice();
        await this.loginPage.login(phone, password);
      }
    };
    
    await use(fixture);
  }
});