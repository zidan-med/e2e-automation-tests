export interface SignInCredentials {
    phone: string;
    password: string;
    reCaptchaToken: string;
  }
  export interface AccountAutomation {
    businessType: string;
    country: string;
    email: string;
    language: string;
    managerName: string;
    phone: string;
    pricingPackage: string;
    restaurantName: string;
    timezone: string;
    reCaptchaToken: string;

  }
  export interface SectionAutomation {
    idRestaurant?: string;
    name: string;
    meals: any[];
  }
  
  export interface ProductAutomation {
    id: string;
    idRestaurant?: string;
    name: string;
    status: 'active';
    price: number;
    description: string;
    section: string;
    img: Record<string, any>;
    options: any[];
    useDefaultDiscount: boolean;
    discount: number;
    sizes: Array<{
      name: string;
      price: number;
    }>;
    menuId?: string;
    imgs: Array<{
      rawFile?: any;
      path?: string;
    }>;
  }
  export interface AtomicOptionAutomation {
    optionGroup: string,
    menuId: string,
    name: string,
    pricePerUnit: number,
  }
  export interface OptionAutomation {
    mandatory: boolean,
    maxTotalOptionsCount: number,
    minTotalOptionsCount: number,
    name: string,
    menuId: string,
    type: string,
  }
  
  export interface CustomerData {
    name: string;
    phoneNumber: string;
    email: string;
    specialRequest: string;
  }
  export interface LoginData {
    phoneNumber: string;
    password: string;
  }
  export interface EnvironmentConfig {
    BASE_URL: string;
    BACKOFFICE_API_URL: string;
    WEBSTORE_API_URL: string;
    BACKOFFICE_URL: string;
    CREDENTIALS: SignInCredentials;
    STORE_ID: string;
    RESTAURANT_ID: string;
    MENU_ID: string;
    claudeApiKey?: string;
    LOCATION_ID: string;
  }
  export interface CreditCardDetail {
    number?: string;
    name?: string;
    expiry?: string;
    cvv?: string;
  }
  export interface newOrderData {
    idRestaurant: string;
    restaurantId: string;
    idEater: '';
    address: string;
    location: {lat:number ,lng:number};
    instructions: string;
    contactless: boolean;
    paymentMethod: string;
    paymentDetails: { type: string };
    discountCodeId: string;
    driverTip: number;
    deliveryOption: string;
    orderMenus: [{
        idMeal: string;
        quantity: number;
        options: []; // You may want to specify a more specific type for 'options'
        size: string;
        section: string}];
    eater: {
        name: string;
        phone: string;
        email: string;
        restaurantId: string;
        address: {lat:number,lng:number,text:string};
    };
    isWebStore: boolean;
    orderSource: string;
    timezone: 'Africa/Casablanca';
    storeLocationId: string;
    itemWeight:'';
    itemToBeDelivered:'';
    pickupAddress:'';
    reCaptchaToken: string
  }
  export interface OrderCollection {
    idOrdre: string;
    idOrder: string;
    orderTotal: number;
    idClient: string;
    tele: string;
    clientName: string;
    orderMenus: {
      options: {
        options: any[]; // Replace 'any' with the actual type if known
        total: number;
      };
      idMeal: string;
      id: string;
      quantity: number;
      price: number;
      originalPrice: number;
      priceWithoutDiscount: number;
      discount: number;
      section: string;
      total: number;
      totalWithoutTax: number;
      taxTotal: number;
      totalWithoutDiscount: number;
      subTotalHT: number;
      name: string;
      _id: string;
    }[];
    storeLocationId: string;
    orderAddress: string;
    restaurantName: string;
    restaurantImg: {
      path: string;
    };
    restaurantAddress: string;
    orderPrice: number;
    deliveryPrice: number;
    deliveryFee: number;
    freeDelivery: boolean;
    deliveryZoneName: string;
    driverTip: number;
    lng: string;
    lat: string;
    Rlng: string;
    Rlat: string;
    idRestaurant: string;
    instructions: string;
    contactless: boolean;
    paymentMethod: string;
    currency: string;
    distance: number;
    time: string; // ISO timestamp
    restaurantTax: number;
    restaurantTaxRate: number;
    deliveredOrders: number;
    cancelledOrders: number;
    duration: number;
    discount: number;
    mealTotalWithoutDiscount: number;
    mealTotalIncome: number;
    subTotalHT: number;
    acceptedAutomatically: boolean;
    state: string;
    deliveryOption: string;
    isWebStore: boolean;
    orderSource: string;
    isCustom: boolean;
    itemWeight: number;
    itemToBeDelivered: string;
    pickupLocation: Record<string, unknown>;
    isRestaurantDriver: boolean;
    clickedAt: string; // ISO timestamp
  }
  
