const SERVER_ENDPOINT = {
    WEBSTORE_SEND_ORDER: "webstore/api/sendOrder",
    DRIVER_LOGIN: "live/api/driver/signin/verify"
}
export default SERVER_ENDPOINT;