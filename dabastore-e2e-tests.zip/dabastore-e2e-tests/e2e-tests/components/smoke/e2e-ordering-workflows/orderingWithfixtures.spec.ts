import { test } from '../../../fixtures/fixtures';
import { CONFIG } from '../../../config/environments';
import { TestDataGenerator } from '../../../utils/test-data-generator';

test.beforeEach('E2E order flow 1 - from customer order to admin acceptance', async ({ 
  request,
  webstoreOrdering,
  backofficeActions,
  apiHelper
}) => {
  // Set timeout
  test.setTimeout(180000);
  
  const customerData = TestDataGenerator.generateCustomerData();
  
  const testData = await apiHelper.createTestData(request, CONFIG.RESTAURANT_ID, CONFIG.MENU_ID);
  const sectionResponse = testData.section;
  const productResponse = testData.product;

  try {
    const orderDetails = await webstoreOrdering.completeOrder({
      menuId: CONFIG.MENU_ID,
      sectionName: sectionResponse.name,
      productName: productResponse.name,
      customerData: customerData,
      paymentMethod: 'cash',
      discountCode: ''
    });
    
    const orderId = orderDetails.id;
    const price = orderDetails.orderTotal;

    console.log(`Order created with ID: ${orderId}`);
    
    await webstoreOrdering.verifyOrderConfirmationDelivery({
      orderId: orderId,
      productName: productResponse.name,
      promo: orderDetails.mealTotalDiscount || 0,
      subtotal: orderDetails.restaurantTotal,
      tip: orderDetails.driverTip || 0,
      deliveryFee: orderDetails.finalDeliveryFee,
      total: orderDetails.orderTotal
    });

    await backofficeActions.navigateToBackoffice();
    
    await backofficeActions.login(CONFIG.CREDENTIALS.phone.substring(1), CONFIG.CREDENTIALS.password);

    await backofficeActions.acceptNewOrders();
    await backofficeActions.navigateToAcceptOrders();
    await backofficeActions.assignOrderToDriver(orderId, price);

    await webstoreOrdering.verifyOrderStatusUpdateDelivery('Validé');
    
    await backofficeActions.navigateToInProgressOrders();
    //await backofficeActions.assignOrderToDriver(orderId, price);

    //await backofficeActions.openOrderDetails(orderId);
    //await backofficeActions.updateOrderStatus(status);
    // Verify order status update
    await webstoreOrdering.verifyOrderStatusUpdateDelivery('Validé');
    
  } finally {
    // Clean up test data
    if (productResponse?.id) {
      await apiHelper.deleteProduct(request, productResponse.id);
    }
    if (sectionResponse?.id) {
      await apiHelper.deleteSection(request, sectionResponse.id);
    }
  }
});
