import { test } from '../../../fixtures/fixtures';
import { CONFIG } from '../../../config/environments';
import { TestDataGenerator } from '../../../utils/test-data-generator';
import { CustomerData } from '../../../models/types';
import { ApiHelper } from '../../../helpers/api-helper.ts';
import { AuthHelper } from '../../../helpers/auth-helper.ts';

test.describe('E2E Order Flows', () => {
  // variables that will be used across tests
  let testData: {section: any; product: any; option?: any; atomicOption?: any; discounts: any;};
  let sectionResponse: { name: any; id: string; };
  let productResponse: { name: any; id: string; };
  let customerData: CustomerData;
  let accountData: any;
  let optionResponse: any;
  let atomicoptionResponse: any;
  let accountResponse: any;
  //let accountData: any;
  let discountCodeResponse: { code: any; }[];
  // Using beforeEach to set up common test data before each test
  test.beforeEach(async ({ request, apiHelper }) => {
    // Set test timeout
    test.setTimeout(90000);
    
    // Generate customer data for the test
    customerData = TestDataGenerator.generateCustomerData();
    //accountData = TestDataGenerator.generatAccountData();
    const authHelper = new AuthHelper();

    const accountData = TestDataGenerator.generatAccountData();
    const accountResponse = await ApiHelper.createAccountTestData(request);
    console.log('Created order account:', (accountResponse));
    console.log('Created order account data:', (accountData));
    // Create test data using the API helper
    //accountResponse = await apiHelper.createAccountTestData(request);
 // Setup
    const authToken = await authHelper.getToken(request, accountData.phone);
    //const apiHelper = new ApiHelper(authToken);
    testData = await apiHelper.createTestData(request, accountResponse.account.id, accountResponse.account.id + '_MENU_DEFAULT');
    //accountResponse = testData.account;
    sectionResponse = testData.section;
    productResponse = testData.product;
    optionResponse = testData.option;
    atomicoptionResponse = testData.atomicOption;
    discountCodeResponse = testData.discounts;
    
    // Log setup information
    //console.log(`Test setup complete with account: ${testData.account}`)
    console.log(`Test setup complete with account: ${accountResponse}`);
    //console.log(`Test setup complete with discount: ${discountCodeResponse}`);
    //console.log(`Test setup complete with discount: ${discountCodeResponse[1].code}`);

  });
  
  // Using afterEach to clean up test data after each test
  test.afterEach(async ({ request, apiHelper }) => {
    // Clean up test data
    if (productResponse?.id) {
      await apiHelper.deleteProduct(request, productResponse.id);
      console.log(`Deleted product: ${productResponse.id}`);
    }
    if (sectionResponse?.id) {
      await apiHelper.deleteSection(request, sectionResponse.id);
      console.log(`Deleted section: ${sectionResponse.id}`);
    }
  });
  
  test('Order flow with cash payment with discount code type percent', async ({ 
    webstoreOrdering, 
    backofficeActions
  }) => {
    // Complete the order with cash payment
    const orderDetails = await webstoreOrdering.completeOrder({
      menuId: accountResponse.account.id + '_MENU_DEFAULT',
      sectionName: sectionResponse.name, 
      productName: productResponse.name,
      customerData: customerData,
      paymentMethod: 'cash',
      discountCode: discountCodeResponse[1].code,
    });
    //await webstoreOrdering.applyDicountCode(discountCodeResponse[1].code);
    //const orderDetail = await webstoreOrdering.submitOrder();
    const orderId = orderDetails.id;
    const price = orderDetails.orderTotal;

    //console.log(`Order created with ID: ${orderDetail} using cash payment`);
    
    // Verify order confirmation
    await webstoreOrdering.verifyOrderConfirmationDelivery({
      orderId: orderId,
      productName: productResponse.name,
      promo: orderDetails.mealTotalDiscount || 0,
      subtotal: orderDetails.restaurantTotal,
      tip: orderDetails.driverTip || 0,
      deliveryFee: orderDetails.finalDeliveryFee,
      total: orderDetails.orderTotal
    });

    // Process in backoffice
    await backofficeActions.navigateToBackoffice();
    await backofficeActions.login(CONFIG.CREDENTIALS.phone.substring(1), CONFIG.CREDENTIALS.password);
    await backofficeActions.acceptNewOrders();
    await backofficeActions.navigateToAcceptOrders();
    await backofficeActions.assignOrderToDriver(orderId, price);

    // Verify order status
    await webstoreOrdering.verifyOrderStatusUpdateDelivery('Validé');
    
    // Navigate to in progress orders
    await backofficeActions.navigateToInProgressOrders();
    
    // Final status verification
    await webstoreOrdering.verifyOrderStatusUpdateDelivery('Validé');
  });
  
  test('Order flow with online payment with discount code type percent', async ({ 
    webstoreOrdering, 
    backofficeActions
  }) => {
    // Complete the order
    const orderDetails = await webstoreOrdering.completeOrder({
      menuId: CONFIG.MENU_ID,
      sectionName: sectionResponse.name, 
      productName: productResponse.name,
      customerData: customerData,
      paymentMethod: 'cash',
      discountCode:'',
    });
    
    const orderId = orderDetails.id;
    const price = orderDetails.orderTotal;

    console.log(`Order created with ID: ${orderId} using online payment`);
    
    // Verify order confirmation
    await webstoreOrdering.verifyOrderConfirmationDelivery({
      orderId: orderId,
      productName: productResponse.name,
      promo: orderDetails.mealTotalDiscount || 0,
      subtotal: orderDetails.restaurantTotal,
      tip: orderDetails.driverTip || 0,
      deliveryFee: orderDetails.finalDeliveryFee,
      total: orderDetails.orderTotal
    });

    // Process in backoffice
    await backofficeActions.navigateToBackoffice();
    await backofficeActions.login(CONFIG.CREDENTIALS.phone.substring(1), CONFIG.CREDENTIALS.password);
    await backofficeActions.acceptNewOrders();
    await backofficeActions.navigateToAcceptOrders();
    await backofficeActions.assignOrderToDriver(orderId, price);

    // Verify order status
    await webstoreOrdering.verifyOrderStatusUpdateDelivery('Validé');
    
    // Navigate to in progress orders
    await backofficeActions.navigateToInProgressOrders();
    
    // Final status verification
    await webstoreOrdering.verifyOrderStatusUpdateDelivery('Validé');
  });
  
  test('Order flow with TPE payment with discount code type percent', async ({ 
    webstoreOrdering, 
    backofficeActions
  }) => {
    // Complete the order with TPE payment
    const orderDetails = await webstoreOrdering.completeOrder({
      menuId: CONFIG.MENU_ID,
      sectionName: sectionResponse.name, 
      productName: productResponse.name,
      customerData: customerData,
      paymentMethod: 'tpe'
    });
    
    const orderId = orderDetails.id;
    const price = orderDetails.orderTotal;

    console.log(`Order created with ID: ${orderId} using TPE payment`);
    
    // Verify order confirmation
    await webstoreOrdering.verifyOrderConfirmationDelivery({
      orderId: orderId,
      productName: productResponse.name,
      promo: orderDetails.mealTotalDiscount || 0,
      subtotal: orderDetails.restaurantTotal,
      tip: orderDetails.driverTip || 0,
      deliveryFee: orderDetails.finalDeliveryFee,
      total: orderDetails.orderTotal
    });

    // Process in backoffice
    await backofficeActions.navigateToBackoffice();
    await backofficeActions.login(CONFIG.CREDENTIALS.phone.substring(1), CONFIG.CREDENTIALS.password);
    await backofficeActions.acceptNewOrders();
    await backofficeActions.navigateToAcceptOrders();
    await backofficeActions.assignOrderToDriver(orderId, price);

    // Verify order status
    await webstoreOrdering.verifyOrderStatusUpdateDelivery('Validé');
    
    // Navigate to in progress orders
    await backofficeActions.navigateToInProgressOrders();
    
    // Final status verification
    await webstoreOrdering.verifyOrderStatusUpdateDelivery('Validé');
  });
});
