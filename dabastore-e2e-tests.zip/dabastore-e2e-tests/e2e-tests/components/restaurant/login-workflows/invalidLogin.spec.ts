
import { test, expect } from '@playwright/test';
import { BackofficeLoginPage } from '/Users/mac/Downloads/dossier sans titre/dabastore-e2e-tests/e2e-tests/pages/backoffice/login-page';
import { CONFIG } from '/Users/mac/Downloads/dossier sans titre/dabastore-e2e-tests/e2e-tests/config/environments';
import { TestDataGenerator } from '/Users/mac/Downloads/dossier sans titre/dabastore-e2e-tests/e2e-tests/utils/test-data-generator.ts';


test.describe('Login functionality with invalid credentials', () => {

    test('should show error message for invalid phone', async ({ page }) => {
        const backofficeLoginPage = new BackofficeLoginPage(page);
        const loginData = TestDataGenerator.generateLoginData();
        //loginData.phoneNumber = "invalid-phone"; 
        
        await backofficeLoginPage.navigateToBackoffice();
      
        const responsePromise = new Promise<{status: number, body: any}>(async (resolve) => {
          page.on('response', async response => {
            if (response.url().includes('/api/manager/signin/start')) {
              try {
                const status = response.status();
                // Clone the response before the page potentially closes
                const bodyText = await response.text().catch(() => '');
                const body = bodyText ? JSON.parse(bodyText) : null;
                
                resolve({ status, body });
              } catch (e) {
                resolve({ 
                  status: response.status(), 
                  body: `Error processing response: ${e.message}` 
                });
              }
            }
          });
        });
      
        //trigger the login with invalid phone
        //await backofficePage.login(loginData.phoneNumber,loginData.password);
        await backofficeLoginPage.login(loginData.phoneNumber, "", 'phone');
        // Check the response status and body
        const responseData = await Promise.race([
          responsePromise,
          new Promise<{status: number, body: string}>((resolve) => 
            setTimeout(() => resolve({ status: 0, body: 'Timeout waiting for response' }), 5000)
          )
        ]);
        
        // Validate the response data
        if (responseData.status !== 0) {
          expect(responseData.status).toBe(404); // Adjust based on your API
          expect(responseData.body).toHaveProperty('error'); // Adjust based on API response format
        } else {
          test.fail(true, 'Timed out waiting for API response');
        }
        
        console.log('API response validated:', responseData);
        await  page.close();  

        //await expect(page.getByText('No such Manager!')).toBeVisible({ timeout: 5000 });
      });

    test('should show error message for invalid password', async ({ page }) => {
        const backofficeLoginPage = new BackofficeLoginPage(page);
        const loginData = TestDataGenerator.generateLoginData();
        //loginData.phoneNumber = "invalid-phone"; 
        
        await backofficeLoginPage.navigateToBackoffice();
      
        const responsePromise = new Promise<{status: number, body: any}>(async (resolve) => {
          page.on('response', async response => {
            if (response.url().includes('/api/manager/signin/verify')) {
              try {
                const status = response.status();
                const bodyText = await response.text().catch(() => '');
                const body = bodyText ? JSON.parse(bodyText) : null;
                
                resolve({ status, body });
              } catch (e) {
                resolve({ 
                  status: response.status(), 
                  body: `Error processing response: ${e.message}` 
                });
              }
            }
          });
        });
      
        //await backofficePage.login(loginData.phoneNumber,loginData.password);
        await backofficeLoginPage.login(CONFIG.CREDENTIALS.phone.substring(1), loginData.password);
        // Check the response status and body
        const responseData = await Promise.race([
          responsePromise,
          new Promise<{status: number, body: string}>((resolve) => 
            setTimeout(() => resolve({ status: 0, body: 'Timeout waiting for response' }), 5000)
          )
        ]);
        
        // Validate the response data
        if (responseData.status !== 0) {
          expect(responseData.status).toBe(401);
          expect(responseData.body).toHaveProperty('error'); 
        } else {
          test.fail(true, 'Timed out waiting for API response');
        }
        
        console.log('API response validated:', responseData);
        await  page.close();  

    });

}); 


  


    