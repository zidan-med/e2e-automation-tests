import { test, expect } from '@playwright/test';
import { BackofficeLoginPage } from '/Users/mac/Downloads/dossier sans titre/dabastore-e2e-tests/e2e-tests/pages/backoffice/login-page';
import { CONFIG } from '/Users/mac/Downloads/dossier sans titre/dabastore-e2e-tests/e2e-tests/config/environments';


test('Test Manager login', async ({ page }) => {
    const backofficeLoginPage = new BackofficeLoginPage(page);

    await backofficeLoginPage.navigateToBackoffice();
    const dashboardPage = await backofficeLoginPage.login(CONFIG.CREDENTIALS.phone.substring(1), CONFIG.CREDENTIALS.password);
    //await backofficePage.navigateToOrders();
    await expect(dashboardPage.getByTestId('dashboard')).toBeVisible();
    await  page.close();  

});
