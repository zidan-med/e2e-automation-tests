import { test } from '@playwright/test';
import { AuthHelper } from '../../../helpers/auth-helper.ts';
//import { ApiHelper } from '../../../../helpers/api-helper';
//import { TestDataGenerator } from '../../../../utils/test-data-generator.ts';
//import { WebstorePage } from '/Users/mac/Downloads/dossier sans titre/dabastore-e2e-tests/e2e-tests/pages/webstore/webstore-page.ts';
import { ApiHelper } from '../../../helpers/api-helper.ts';
import { getEnvironment, CONFIG } from '../../../config/environments.ts';
import { TestDataGenerator } from '../../../utils/test-data-generator.ts';
import { BackofficeActionsPage } from '../../../pages/backoffice/backoffice-page.ts';
import { BackofficeLoginPage } from '../../../pages/backoffice/login-page.ts';

// Main test
test('E-commerce order(delivery type) flow test', async ({ request, page }) => {
  // Log current environment
  console.log(`Running tests in ${getEnvironment()} environment`);
  console.log(`Using BASE_URL: ${CONFIG.WEBSTORE_API_URL}`);
  
  // Setup
  const authHelper = new AuthHelper();
  const authToken = await authHelper.getToken(request);
  const apiHelper = new ApiHelper(authToken);
  //const webstorePage = new WebstorePage(page);
  const backofficeLoginPage = new BackofficeLoginPage(page);
  const backofficeActionsPage = new BackofficeActionsPage(page);


  const sectionData = TestDataGenerator.generateSectionData(CONFIG.RESTAURANT_ID);
  const sectionResponse = await apiHelper.createSection(request, sectionData);
  //console.log('Created section:', sectionResponse);
  
  const productData = TestDataGenerator.generateProductData(sectionResponse.id, CONFIG.MENU_ID);
  const productResponse = await apiHelper.createProduct(request, productData);
  //console.log('Created product:', productResponse);
  
  //const selectPaymentOption = WebstorePage(CONFIG.RESTAURANT_ID);
  //const orderData = TestDataGenerator.generateOrderData(CONFIG.RESTAURANT_ID, sectionResponse.id, productResponse.id, ('cash'));

  const orderData = TestDataGenerator.generateOrderData(CONFIG.RESTAURANT_ID, sectionResponse.id, productResponse.id, ('cash'));
  const orderResponse = await apiHelper.createOrder(orderData);
  console.log('Created order :', (orderResponse));
  console.log('Created order data:', (orderData));

  await backofficeLoginPage.navigateToBackoffice();
  await backofficeLoginPage.login(CONFIG.CREDENTIALS.phone, CONFIG.CREDENTIALS.password);
    //await backofficePage.navigateToAcceptedOrders();
  await backofficeActionsPage.acceptNewOrders();
  await backofficeActionsPage.navigateToAcceptOrders();
  await backofficeActionsPage.assignOrderToDriver(orderResponse.id, orderResponse.orderTotal);

  await  page.close();  

});

