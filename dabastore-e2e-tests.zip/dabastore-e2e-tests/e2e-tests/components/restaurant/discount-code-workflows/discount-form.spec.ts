/*
import { test, expect, request } from '@playwright/test';
import { DiscountFormPage } from '/Users/mac/Downloads/dossier sans titre/dabastore-e2e-tests/e2e-tests/pages/backoffice/discount-page.ts';
import { BackofficeLoginPage } from '../../../pages/backoffice/login-page';

import { CONFIG, getEnvironment } from '../../../config/environments';

test.describe('Discount code workflow', () => {
  let discountForm: DiscountFormPage;

  test.beforeEach(async ({request, page }) => {

    console.log(`Running tests in ${getEnvironment()} environment`);
    //console.log(`Using BASE_URL: ${CONFIG.WEBSTORE_API_URL}`);
    
    // Setup
    //const authHelper = new AuthHelper();
    //const authToken = await authHelper.getToken(request);
    //const apiHelper = new ApiHelper(authToken);
    //const api1Helper = new Api1Helper();
  
    //const webstorePage = new WebstorePage(page);
    const backofficePage = new BackofficeLoginPage(page);
    const discountForm = new DiscountFormPage(page);
    await backofficePage.navigateToBackoffice();
    const dashboardPage = await backofficePage.login(CONFIG.CREDENTIALS.phone.substring(1), CONFIG.CREDENTIALS.password);
    //await backofficePage.navigateToOrders();
    await expect(dashboardPage.getByTestId('dashboard')).toBeVisible();
    await discountForm.navigateToDiscountsection();
    await discountForm.openDiscountForm();
    
  });


  test('create discount code basic', async ({ }) => {
    
    await discountForm.createBasicPromoCode({
        code: 'FREESHIP2025',
        discountType: 'free-shipping'
    });
    await discountForm.submitForm;
    
    await discountForm.checkSuccessMessage;
});
  
  test('Create discount code free delivery', async () => {
    
    await discountForm.createBasicPromoCode({
        code: 'FREESHIP2025',
        discountType: 'free-shipping'
    });
    
    await discountForm.checkDiscountSuccess();
});

  test('Create discount code pourcentage', async () => {
    await discountForm.createBasicPromoCode({
      code: 'PERCENT25',
      discountType: 'percentage',
      value: '25',
      minOrderValue: '100',
      limitType: 'usage-limit',
      limitValue: '500'
    });
    
    await discountForm.checkDiscountSuccess();
  });

  test('Create discount code fixed value', async () => {
    await discountForm.createBasicPromoCode({
      code: 'FIXED50',
      discountType: 'fixed-value',
      value: '50',
      limitType: 'no-limit'
    });
    
    await discountForm.checkDiscountSuccess();
  });



  test('Verify discount code form displays free delivery', async () => {
    
    //await discountForm.;
    await discountForm.selectFreeShippingOption();
    
    await expect(discountForm.percentageDiscountInput).toBeHidden({ timeout: 1000 }).catch(() => {});
    await expect(discountForm.fixedValueDiscountInput).toBeHidden({ timeout: 1000 }).catch(() => {});
  });

  test('Verify discount code form displays pourcentage', async () => {
    await discountForm.selectPercentageDiscountOption();
    
    await expect(discountForm.percentageDiscountInput).toBeVisible();
    await expect(discountForm.fixedValueDiscountInput).toBeHidden({ timeout: 1000 }).catch(() => {});
  });

  test('Verify discount code form displays fixed value', async () => {
    await discountForm.selectFixedValueDiscountOption();
    
    await expect(discountForm.fixedValueDiscountInput).toBeVisible();
    await expect(discountForm.percentageDiscountInput).toBeHidden({ timeout: 1000 }).catch(() => {});
  });
});

*/