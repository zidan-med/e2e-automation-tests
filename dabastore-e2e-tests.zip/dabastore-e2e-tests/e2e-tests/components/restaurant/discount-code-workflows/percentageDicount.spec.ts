

import { test, expect } from '@playwright/test';
import { BackofficeLoginPage } from '../../../pages/backoffice/login-page';
import { DiscountFormPage } from '../../../pages/backoffice/discount-page';
import { CONFIG } from '../../../config/environments';

test('Create discount code pourcentage', async ({ page }) => {
    const backofficePage = new BackofficeLoginPage(page);
    const discountForm = new DiscountFormPage(page);

    await backofficePage.navigateToBackoffice();
    const dashboardPage = await backofficePage.login(CONFIG.CREDENTIALS.phone.substring(1), CONFIG.CREDENTIALS.password);

    await expect(dashboardPage.getByTestId('dashboard')).toBeVisible();
    await discountForm.navigateToDiscountsection();
    await discountForm.openDiscountForm();
    await discountForm.createBasicPromoCode({
        code: 'PERCENT25',
        discountType: 'percentage',
        value: '25',
        //minOrderValue: '100',
        limitType: 'usage-limit',
        //limitValue: '500'
      });

    await discountForm.submitForm();
    await discountForm.checkDiscountSuccess(); 
    await  page.close();

});