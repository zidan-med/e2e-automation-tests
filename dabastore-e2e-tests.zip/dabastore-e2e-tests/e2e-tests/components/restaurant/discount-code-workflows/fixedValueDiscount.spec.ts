

import { test, expect } from '@playwright/test';
import { BackofficeLoginPage } from '../../../pages/backoffice/login-page';
import { DiscountFormPage } from '../../../pages/backoffice/discount-page';
import { CONFIG } from '../../../config/environments';

test('Create discount code fixed value', async ({ page }) => {
    const backofficeLoginPage = new BackofficeLoginPage(page);
    const discountForm = new DiscountFormPage(page);

    await backofficeLoginPage.navigateToBackoffice();
    const dashboardPage = await backofficeLoginPage.login(CONFIG.CREDENTIALS.phone.substring(1), CONFIG.CREDENTIALS.password);

    await expect(dashboardPage.getByTestId('dashboard')).toBeVisible();
    await discountForm.navigateToDiscountsection();
    await discountForm.openDiscountForm();
    await discountForm.createBasicPromoCode({
        code: 'PERCENT25',
        discountType: 'fixed-value',
        value: '25',
        minOrderValue: '100',
        //limitType: 'usage-limit',
        //limitValue: '500'
      });

    await discountForm.minOrderValueToggle.click();
    await discountForm.setMinimumOrderValue('100');
    await discountForm.submitForm();
    await discountForm.checkDiscountSuccess(); 
    await page.close();

});