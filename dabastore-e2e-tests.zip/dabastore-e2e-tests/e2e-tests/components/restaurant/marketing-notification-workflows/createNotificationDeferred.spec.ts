import { test, expect } from '@playwright/test';
import { BackofficeLoginPage } from '../../../pages/backoffice/login-page';
//import { DiscountFormPage } from '../../../pages/backoffice/discount-page';
import { CONFIG } from '../../../config/environments';
import { NotificationFormPage } from '../../../pages/backoffice/notifcation-page';

test('Create marketing notification Deferred', async ({ page }) => {
    const backofficeLoginPage = new BackofficeLoginPage(page);
    const notificationFormPage = new NotificationFormPage(page);

    await backofficeLoginPage.navigateToBackoffice();
    const dashboardPage = await backofficeLoginPage.login(CONFIG.CREDENTIALS.phone.substring(1), CONFIG.CREDENTIALS.password);

    await expect(dashboardPage.getByTestId('dashboard')).toBeVisible();
    const today = new Date();
    const randomDays = Math.floor(Math.random() * 365) + 1; // Random days from 1 to 365
    today.setDate(today.getDate() + randomDays); // Add random days to current date
  
    // Format the date as 'YYYY-MM-DD' (required by <input type="date">)
    const year = today.getFullYear();
    const month = String(today.getMonth() + 1).padStart(2, '0');
    const day = String(today.getDate()).padStart(2, '0');
    const hours = String(today.getHours()).padStart(2, '0');
    const minutes = String(today.getMinutes()).padStart(2, '0');
  
    // Create a string in the format 'yyyy-mm-ddThh:mm'
    const futureDateTime = `${year}-${month}-${day} ${hours}:${minutes} GMT+1`;
      console.log(futureDateTime)

    await notificationFormPage.navigateToNotificationSection();
    await notificationFormPage.openNotificationForm();
    await notificationFormPage.createBasicNotification({
        title: 'hello',
        notificationType: 'deferred',
        message: 'good morning',
        excutionTime: futureDateTime
    });

    console.log(futureDateTime)
    await  page.close();  

    
});
