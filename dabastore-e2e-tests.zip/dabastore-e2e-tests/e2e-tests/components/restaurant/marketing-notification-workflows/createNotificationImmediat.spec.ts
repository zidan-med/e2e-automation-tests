

import { test, expect } from '@playwright/test';
import { BackofficeLoginPage } from '../../../pages/backoffice/login-page';
//import { DiscountFormPage } from '../../../pages/backoffice/discount-page';
import { CONFIG } from '../../../config/environments';
import { NotificationFormPage } from '../../../pages/backoffice/notifcation-page';

test('Create marketing notification immediat', async ({ page }) => {

    const backofficeLoginPage = new BackofficeLoginPage(page);
    const notificationFormPage = new NotificationFormPage(page);

    await backofficeLoginPage.navigateToBackoffice();
    const dashboardPage = await backofficeLoginPage.login(CONFIG.CREDENTIALS.phone.substring(1), CONFIG.CREDENTIALS.password);

    await expect(dashboardPage.getByTestId('dashboard')).toBeVisible();

    await notificationFormPage.navigateToNotificationSection();
    await notificationFormPage.openNotificationForm();

    
    const responsePromise = page.waitForResponse(response => 
        response.request().method() === 'POST' && 
        response.url().includes(`${CONFIG.BACKOFFICE_API_URL}/notification`));
        

    await notificationFormPage.createBasicNotification({
        title: 'hello',
        notificationType: 'immediat',
        message: 'good morning',
        excutionTime:'0'
    });
    
    const response = await responsePromise;
    const responseBody = await response.json();
    console.log('Response body:', responseBody.status, responseBody.id);
    //await notificationFormPage.checkNotificationResponse(page);
    //console.log('Notification response:', response);
    await  page.close();  

});