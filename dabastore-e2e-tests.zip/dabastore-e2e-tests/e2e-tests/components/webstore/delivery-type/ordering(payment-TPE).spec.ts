import { test, expect } from '@playwright/test';
import { AuthHelper } from '/Users/mac/Downloads/dossier sans titre/dabastore-e2e-tests/e2e-tests/helpers/auth-helper';
import { ApiHelper } from '/Users/mac/Downloads/dossier sans titre/dabastore-e2e-tests/e2e-tests/helpers/api-helper';
import { WebstorePage } from '../../../pages/webstore/webstore-page';
import { BackofficeActionsPage } from '../../../pages/backoffice/backoffice-page';
import { TestDataGenerator } from '/Users/mac/Downloads/dossier sans titre/dabastore-e2e-tests/e2e-tests/utils/test-data-generator.ts';
import { CONFIG, getEnvironment } from '../../..//config/environments';

// Main test
test('Webstore order(delivery type & TPE as a payment method) flow test', async ({ request, page }) => {
  // Log current environment
  console.log(`Running tests in ${getEnvironment()} environment`);
  console.log(`Using BASE_URL: ${CONFIG.BASE_URL}`);
  test.setTimeout(120000);

  // Setup
  const authHelper = new AuthHelper();
  const authToken = await authHelper.getToken(request);
  const apiHelper = new ApiHelper(authToken);
  const webstorePage = new WebstorePage(page);
  //const backofficePage = new BackofficePage(page);
  const customerData = TestDataGenerator.generateCustomerData();
  const backofficeActionsPage = new BackofficeActionsPage(page)

  
  let sectionResponse;
  let productResponse;
  
  // Test data creation
  try {
    const sectionData = TestDataGenerator.generateSectionData(CONFIG.RESTAURANT_ID);
    sectionResponse = await apiHelper.createSection(request, sectionData);
    console.log('Created section:', sectionResponse);
    
    const productData = TestDataGenerator.generateProductData(sectionResponse.id, CONFIG.MENU_ID);
    productResponse = await apiHelper.createProduct(request, productData);
    console.log('Created product:', productResponse);
    
    // Customer journey
    await webstorePage.navigateToWebstore(CONFIG.MENU_ID);
    await webstorePage.selectSection(sectionData.name);
    await webstorePage.selectProduct(productData.name);
    await webstorePage.addToCart();
    await webstorePage.proceedToCheckout();
    await webstorePage.fillCheckoutDeliveryForm(customerData);
    await webstorePage.selectPaymentOption('tpe');
    await webstorePage.submitOrder();
    
    await backofficeActionsPage.navigateToBackoffice();
    await backofficeActionsPage.login(CONFIG.CREDENTIALS.phone.substring(1), CONFIG.CREDENTIALS.password);
    await backofficeActionsPage.acceptNewOrders();
    await  page.close();  

  } catch (error) {
    console.error('Test execution error:', error);
  } finally {
    if (productResponse?.id) {
      const productDeleteStatus = await apiHelper.deleteProduct(request, productResponse.id);
      console.log(`Product deletion status: ${productDeleteStatus}`);
    }
    
    if (sectionResponse?.id) {
      const sectionDeleteStatus = await apiHelper.deleteSection(request, sectionResponse.id);
      console.log(`Section deletion status: ${sectionDeleteStatus}`);
    }
  }
});

