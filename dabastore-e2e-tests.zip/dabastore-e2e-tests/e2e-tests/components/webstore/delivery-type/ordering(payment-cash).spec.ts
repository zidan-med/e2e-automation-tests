import { test, expect } from '@playwright/test';
import { AuthHelper } from '../../../helpers/auth-helper.ts';
import { ApiHelper } from '../../../helpers/api-helper.ts';
import { WebstorePage } from '../../../pages/webstore/webstore-page.ts';
import { TestDataGenerator } from '../../../utils/test-data-generator.ts';
import { CONFIG, getEnvironment } from '../../../config/environments.ts';
import { BackofficeLoginPage } from '../../../pages/backoffice/login-page.ts';
import { BackofficeActionsPage } from '../../../pages/backoffice/backoffice-page.ts';

// Main test
test('Webstore order(delivery type) flow test', async ({ request, page }) => {
  //console.log(`Running tests in ${getEnvironment()} environment`);
  //console.log(`Using BASE_URL: ${CONFIG.BASE_URL}`);
  test.setTimeout(120000);
  const accountData = TestDataGenerator.generatAccountData();
  const authHelper = new AuthHelper();

  const accountResponse = await authHelper.createAccount(request, accountData);
  console.log('Created order account:', (accountResponse));
  console.log('Created order account data:', (accountData));
  let authStart = await authHelper.authStart(request, accountData.phone);
  console.log('Created  authStart:', (authStart));

  const authSetup = await authHelper.authSetup(request, authStart, accountData.phone);
  console.log('Created  authSetup:', (authSetup));

  const authToken = await authHelper.getToken(request, accountData.phone);
  const apiHelper = new ApiHelper(authToken);
  const webstorePage = new WebstorePage(page);
  const backofficeLoginPage = new BackofficeLoginPage(page);
  const backofficeActionsPage = new BackofficeActionsPage(page)
  const customerData = TestDataGenerator.generateCustomerData();
  
  let sectionResponse;
  let productResponse;
  
  // Test data creation
  try {
    const sectionData = TestDataGenerator.generateSectionData(CONFIG.RESTAURANT_ID);
    sectionResponse = await apiHelper.createSection(request, sectionData);
    //console.log('Created section:', sectionResponse);
    
    const productData = TestDataGenerator.generateProductData(sectionResponse.id, CONFIG.MENU_ID);
    productResponse = await apiHelper.createProduct(request, productData);
    //console.log('Created product:', productResponse);
    
    // webstore Customer 
    await webstorePage.navigateToWebstore(CONFIG.MENU_ID);
    await webstorePage.selectSection(sectionData.name);
    await webstorePage.selectProduct(productData.name);
    await webstorePage.addToCart();
    await webstorePage.proceedToCheckout();
    await webstorePage.fillCheckoutDeliveryForm(customerData);
    await webstorePage.selectPaymentOption('cash');
    const responsePromise = page.waitForResponse(response => 
      response.request().method() === 'POST' && 
      response.url().includes(`${CONFIG.WEBSTORE_API_URL}/sendOrder`));
      
    await webstorePage.submitOrder();
    const response = await responsePromise;
    const responseBody = await response.json();
    //console.log('Response body:', responseBody);
    const orderId = responseBody.id;
    //console.log('orderId:', orderId);
    /*
    const expectedSubtotal = responseBody.subTotalHT;
    //console.log('expectedSubtotal:', expectedSubtotal);
    const expectedPromo = responseBody.orderMenus.discount;
    //console.log('expectedPromo:', expectedPromo);
    const expectedDeliveryFee = responseBody.finalDeliveryFee;
    //console.log('expectedDeliveryFee:', expectedDeliveryFee);
    const expectedTotal = responseBody.orderTotal;
    //console.log('expectedTotal:', expectedTotal);
*/
    await page.waitForURL(`${CONFIG.BASE_URL}/webstore/${CONFIG.STORE_ID}/order/${orderId}`);
    await expect(page.locator('text=Validé')).toBeVisible();
    await expect(page.locator('text=Préparation')).toBeVisible();
    await expect(page.locator('text=Ramassé')).toBeVisible();
    await expect(page.locator('text=Arrivée')).toBeVisible();
    
    await expect(page.getByText('Numéro de la commande:' + ` ${orderId}`)).toBeVisible();
    //const displayedOrderId = await page.locator('input:near(:text("Numéro de la commande"))').inputValue();
    //expect(displayedOrderId).toBe(orderId);
    
    // Verify order summary is displayed
    await expect(page.locator('text=Récapitulatif de votre commande')).toBeVisible();
    //await expect(page.locator('text=Total')).toBeVisible();
      // Extract price information from the response if availabl

  /*
    if (expectedSubtotal) {
      const subtotalText = await page.locator('text=Sous-total').locator('xpath=../..').textContent();
      expect(subtotalText).toContain(expectedSubtotal.toString().replace('.', ','));
    }
    
    if (expectedPromo) {
      const promoText = await page.locator('text=Promo').locator('xpath=../..').textContent();
      expect(promoText).toContain(expectedPromo.toString().replace('.', ','));
    }
    
    if (expectedDeliveryFee) {
      const deliveryText = await page.locator('text=Frais de livraison').locator('xpath=../..').textContent();
      expect(deliveryText).toContain(expectedDeliveryFee.toString().replace('.', ','));
    }
    
    if (expectedTotal) {
      const totalText = await page.locator('text=Total').locator('xpath=../..').textContent();
      expect(totalText).toContain(expectedTotal.toString().replace('.', ','));
    }
     */ 
    //const acceptOrder = TestDataGenerator.generateSectionData(CONFIG.RESTAURANT_ID);
    //const getorders = await apiHelper.getOrderById(request, orderId);
    //console.log('accepted order', getorders);
    //const acceptResponse = await apiHelper.acceptOrder(responseBody);
    //console.log('accepted order', acceptResponse.state);
    //console.log('accepted order', acceptResponse);
    //console.log('accepted order', responseBody);
    await backofficeActionsPage.navigateToBackoffice();
    await backofficeActionsPage.login(CONFIG.CREDENTIALS.phone.substring(1), CONFIG.CREDENTIALS.password);
    await backofficeActionsPage.acceptNewOrders();
    //await page.goto(`${CONFIG.BASE_URL}/webstore/${CONFIG.STORE_ID}/order/${orderId}`);
    //await expect(page.locator('div').filter({ hasText: /^Validé$/ }).getByTestId('CheckIcon')).toBeVisible();
    //await backofficeActionsPage.navigateToAcceptOrders();
    //await backofficeActionsPage.assignOrderToDriver(orderId, expectedTotal);
    

    await  page.close();  


  } catch (error) {
    console.error('Test execution error:', error);
  } finally {
    if (productResponse?.id) {
      const productDeleteStatus = await apiHelper.deleteProduct(request, productResponse.id);
      //console.log(`Product deletion status: ${productDeleteStatus}`);
    }
    
    if (sectionResponse?.id) {
      const sectionDeleteStatus = await apiHelper.deleteSection(request, sectionResponse.id);
      //console.log(`Section deletion status: ${sectionDeleteStatus}`);
    }
  }
});

