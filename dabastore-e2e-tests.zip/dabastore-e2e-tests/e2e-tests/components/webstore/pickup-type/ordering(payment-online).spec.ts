  import { test, expect } from '@playwright/test';
  import { AuthHelper } from '../../../helpers/auth-helper';
  import { ApiHelper } from '../../../helpers/api-helper';
  import { WebstorePage } from '../../../pages/webstore/webstore-page';
  import { OrderConfirmationPage } from '../../../pages/webstore/order-confirmation-page';
  import { BackofficeLoginPage } from '../../../pages/backoffice/login-page';
  import { BackofficeActionsPage } from '../../../pages/backoffice/backoffice-page.ts';
  import { TestDataGenerator } from '../../../utils/test-data-generator.ts';
  import { CONFIG } from '../../../config/environments';
  import { LoginHelper } from '../../../helpers/login-helper.ts';

  test('Wesbtore order flow with UI verification', async ({ request, browser }) => {
    test.setTimeout(180000); // Increase timeout if needed
    
    // Create separate contexts for customer and admin
    const customerContext = await browser.newContext();
    const adminContext = await browser.newContext();
    
    // Create pages from those contexts
    const customerPage = await customerContext.newPage();
    const adminPage = await adminContext.newPage();
    
    // Setup helpers and pages
    const authHelper = new AuthHelper();
    const authToken = await authHelper.getToken(request);
    const apiHelper = new ApiHelper(authToken);
    const webstorePage = new WebstorePage(customerPage);
    const orderConfirmationPage = new OrderConfirmationPage(customerPage);
    const backofficeLoginPage = new BackofficeLoginPage(adminPage);
    const backofficeActionsPage = new BackofficeActionsPage(adminPage);
  
    const customerData = TestDataGenerator.generateCustomerData();
    
    try {
      // Create test data
      const sectionData = TestDataGenerator.generateSectionData(CONFIG.RESTAURANT_ID);
      const sectionResponse = await apiHelper.createSection(request, sectionData);
      
      const productData = TestDataGenerator.generateProductData(sectionResponse.id, CONFIG.MENU_ID);
      const productResponse = await apiHelper.createProduct(request, productData);
      
      // Customer journey
      await customerPage.bringToFront();
      await webstorePage.navigateToWebstore(CONFIG.MENU_ID);
      await webstorePage.selectSection(sectionResponse.name);
      await webstorePage.selectProduct(productResponse.name);
      await webstorePage.addToCart();
      await webstorePage.proceedToCheckout();
      await webstorePage.fillCheckoutPickupForm(customerData);
      //await webstorePage.selectPaymentOption('cash');// change it for the test to online

      const responsePromise = customerPage.waitForResponse(response => 
        response.request().method() === 'POST' && 
        response.url().includes(`${CONFIG.WEBSTORE_API_URL}/sendOrder`));

      await webstorePage.submitOrder();
      const response = await responsePromise;
      const responseBody = await response.json();
      //console.log('Order created with details:', responseBody);
      
      const orderId = responseBody.id;
      const promo = responseBody.mealTotalDiscount;
      const subtotal = responseBody.restaurantTotal;
      //const tip = responseBody.driverTip;
      //const deliveryFee = responseBody.finalDeliveryFee;
      const total = responseBody.orderTotal;
      
      await customerPage.waitForURL(`${CONFIG.BASE_URL}/webstore/${CONFIG.STORE_ID}/order/${orderId}`, { timeout: 30000 });
      
      await orderConfirmationPage.verifyOrderStatusDisplayPickup();
      await orderConfirmationPage.paymentIcon;
      await orderConfirmationPage.payzoneLogo;
      await orderConfirmationPage.SuccessOutlinedIcon;
      await orderConfirmationPage.toastCloseButton;
      await orderConfirmationPage.dabaStoreLogo;
      await orderConfirmationPage.verifyOrderNumber(orderId, customerPage);
      await orderConfirmationPage.verifyOrderSummary();
      await orderConfirmationPage.verifyProductDetails(productData.name);
      await orderConfirmationPage.verifyCancelOrderButton();
      await orderConfirmationPage.verifyOrderpromoAmount(promo);
      await orderConfirmationPage.verifyOrdersubtotalAmount(subtotal);
      //await orderConfirmationPage.verifyOrdertipAmount(tip);
      //await orderConfirmationPage.verifyOrderdeliveryFeeAmount(deliveryFee);
      await orderConfirmationPage.verifyOrdertotalAmount(total);
      
      console.log('Customer order verification complete, proceeding to admin actions');
      
      //await bringPageToFocus(adminPage);
      await backofficeLoginPage.navigateToBackoffice();
      await backofficeLoginPage.login(CONFIG.CREDENTIALS.phone.substring(1), CONFIG.CREDENTIALS.password);
      console.log('Admin logged in successfully');
      
      await backofficeActionsPage.acceptNewOrders();
      console.log('Order accepted by admin');
      //await adminContext.close();

      //await bringPageToFocus(customerPage);
      //await orderConfirmationPage.navigateToOrderPage(CONFIG.STORE_ID, orderId);
      await orderConfirmationPage.verifyOrderStatusUpdatePickup('Validé');
      console.log('Order status verified as Validé on customer page');
      
      //await adminContext.();
      //await bringPageToFocus(adminPage);
      //await backofficeActionsPage.navigateToAcceptOrders();
      //await backofficeActionsPage.assignOrderToDriver(orderId, parseFloat(responseBody.orderTotal));
      //console.log('Order assigned to driver');
      
      //await bringPageToFocus(customerPage);
      //await orderConfirmationPage.navigateToOrderPage(CONFIG.STORE_ID, orderId);
      //await orderConfirmationPage.verifyOrderStatusUpdate('Validé');
      //await orderConfirmationPage.verifyOrderStatusUpdate('Préparation');
      //console.log('Order status verified as Préparation on customer page');
      
      // Optional: Clean up test data
      await apiHelper.deleteProduct(request, productResponse.id);
      await apiHelper.deleteSection(request, sectionResponse.id);
      
    } finally {
      // Clean up all contexts
      await customerContext.close();
      await adminContext.close();
    }
  });