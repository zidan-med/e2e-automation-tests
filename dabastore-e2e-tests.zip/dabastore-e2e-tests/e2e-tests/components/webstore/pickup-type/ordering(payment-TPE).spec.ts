import { test, expect } from '@playwright/test';
import { AuthHelper } from '../../../helpers/auth-helper';
import { ApiHelper } from '../../../helpers/api-helper';
import { WebstorePage } from '../../../pages/webstore/webstore-page.ts';
//import { BackofficePage } from '../../../../pages/backoffice/backoffice-page';
import { TestDataGenerator } from '../../../utils/test-data-generator.ts';
import { CONFIG, getEnvironment } from '../../../config/environments';
import { BackofficeActionsPage } from '../../../pages/backoffice/backoffice-page.ts';


test('Webstore order(pickup type and cash as a payment method) flow test', async ({ request, page }) => {
    // Log current environment
    test.setTimeout(120000);
    console.log(`Running tests in ${getEnvironment()} environment`);
    console.log(`Using BASE_URL: ${CONFIG.BASE_URL}`);
    
    // Setup
    const authHelper = new AuthHelper();
    const authToken = await authHelper.getToken(request);
    const apiHelper = new ApiHelper(authToken);
    const webstorePage = new WebstorePage(page);
    //const backofficePage = new BackofficePage(page);
    const customerData = TestDataGenerator.generateCustomerData();
    const backofficeActionsPage = new BackofficeActionsPage(page);

    
    // Create test data variables outside the try block
    let sectionResponse;
    let productResponse;
    
    // Test data creation
    try {
      const sectionData = TestDataGenerator.generateSectionData(CONFIG.RESTAURANT_ID);
      sectionResponse = await apiHelper.createSection(request, sectionData);
      console.log('Created section:', sectionResponse);
      
      const productData = TestDataGenerator.generateProductData(sectionResponse.id, CONFIG.MENU_ID);
      productResponse = await apiHelper.createProduct(request, productData);
      console.log('Created product:', productResponse);
      
      // Customer journey
      await webstorePage.navigateToWebstore(CONFIG.MENU_ID);
      await webstorePage.selectSection(sectionData.name);
      await webstorePage.selectProduct(productData.name);
      await webstorePage.addToCart();
      await webstorePage.proceedToCheckout();
      await webstorePage.fillCheckoutPickupForm(customerData);
      await webstorePage.submitOrder();
      await backofficeActionsPage.navigateToBackoffice();
      await backofficeActionsPage.login(CONFIG.CREDENTIALS.phone.substring(1), CONFIG.CREDENTIALS.password);
      await backofficeActionsPage.acceptNewOrders();
    
    } catch (error) {
      console.error('Test execution error:', error);
    } finally {
      // Cleanup section in finally block to ensure it always runs
      await  page.close();  

      if (productResponse?.id) {
        const productDeleteStatus = await apiHelper.deleteProduct(request, productResponse.id);
        console.log(`Product deletion status: ${productDeleteStatus}`);
      }
      
      if (sectionResponse?.id) {
        const sectionDeleteStatus = await apiHelper.deleteSection(request, sectionResponse.id);
        console.log(`Section deletion status: ${sectionDeleteStatus}`);
      }
    }
});

