import { EnvironmentConfig } from '../models/types';


export const ENVIRONMENTS: Record<string, EnvironmentConfig> = {
  local: {
    BASE_URL: 'http://localhost:3003',
    BACKOFFICE_API_URL: 'https://beta.daba.store/live/api',
    WEBSTORE_API_URL: 'https://beta.daba.store/webstore/api',
    claudeApiKey: process.env.CLAUDE_API_KEY,
    BACKOFFICE_URL: '',
    CREDENTIALS: {
      phone: '',
      password: '',
      reCaptchaToken: '',
    },
    RESTAURANT_ID: '',
    LOCATION_ID: '',
    MENU_ID: ''
  },
  beta: {
    BASE_URL: 'https://beta.daba.store',
    BACKOFFICE_API_URL: 'https://beta.daba.store/live/api',
    WEBSTORE_API_URL: 'https://beta.daba.store/webstore/api',
    BACKOFFICE_URL: 'https://beta.daba.store/backoffice',
    CREDENTIALS: {
      phone: '+212648588997',
      password: '06659534159@Zidan',
      reCaptchaToken: '03AFcWeA4UxuB6CVTSpAod8fOd30AInaosp_qjRY_ywVU5dIMs4TFI3WXRQo_kodYrH4evF3L8xksoyrThA4RiFdSDGIt5Rbqf2IS12iDSaFxgeMUYyUjmzc49yEtly3DV1IahNqD60wbwPYamHbPuvj5kp5wFOfUt7XkzQsGezc192zj15rzUl1LKdgkqRWK9-JX5amTvI8xoSYGYBriDLtjPLAF3mx6DwbrJYMW6fOcHi0Fx4I2KfxvKfFDs200BiY3e1vPz9ZsdSr7c6ZRZQsfE093lnS-IN3UnZmmeyOPsFJg-d6gQKQvg78KTphijkXG1Y6ROuiGLHE3Pvr92CnpU1kG4STMt1C9dK6-MYh-JOosQWx1ANpqg5YP3FaMi_ar4ASlBDa7EBXXzCYJpSo1bJI6_0-pgH9EqtrOgPZ0sv0y8-89t6UdKJTfyKvzt_Iv2O-xk7PP4qdDCxJpTwnbi7vODVZb6Ms-JG17MnEBKhdxjKYzSTKIviYmMocvvaHl5qLvbD183mavw1o2MQbyV_QzI3lKoT8LX1cHGxv-RUMRxik4TCNM2rjlr1m38pIiAs28mXtJn2dsHhhpGb2B-9BUYgbsc-09iIivG2MgVO2uNUs8GolU6vW6oR-cyYr34Uhe-ZDU3g4vAMJCsp_IRdBfUjSxXi71vGWxPTZDHh0TdiUC59NYA6OlPon2mVMY31BXmNLLdFL15LaoucJhH6DIhWn1BqQ_qX4vPcylRaMr8LTAmK2sRfDJQKnz83L77E9y69aVytKLsWeBpjfAR1Z5vxRrtshjk8Pt3HoR-YC7W_WAp5YjMeyBXWCgFnWGYhTabe90qRVgtL3BTxWXx8K3C4V5lg1cDJs54pcNhTb-pMqoxRQcjpkUWBCo5dBoQD6ikb5h7cej54N0_qJF1fSQEbMOndw9h_p_h8MDLK_IsWuUYP7o7auGJYlf-FwEnjw5-SG24zlO70tdprQmX_4wyDM5_7jWhP9biAs74p7ELCfwMzXMXQ1ncK2YN_6Qb_B__PoS07rSs3rL_elL9Fo_vGv5aXsjoCBvP7XpMS3mnqkHKiOYlMOdsaU8vnNh0YE_0ZHnoW1858Khd2IG71-OzeQVTUVUl_vsB6rSy8mcOCbgua8poatjo3_pASbhqDWH0xlaq8m0nlYC96zk1WfZgqz65qRWPmvWhif-WpsKli_cXjIF6FHAuQIIdzbK4QF_Wp_a9KAAOVZyRK5QJPI6ftg63odul2lKqnQ93wHVBnsSTZQ9AHzWDo6E5xxUMjhl17664a3n7JnHXV9AJQe15uhvQCV2eD87oiDZG1UH35HZbiffPUdutA-Od_RoK7Eu7R1HxSM1JQWqQURab3e43vQKI3T4OXunRe06WKPWQEjJd3PvfusXNibTbLH9YUgXbLFbUNZdAKrBDshgplWQnzI3ZzIEcV6qfbAfUxNB_duInM542Eo8QtiZsTbHlBMT34wdqE6ivFppXgyjxQgr2FbppS8Tf0OvrQ5fUgYF-vVgOO-BwjYZ4a81etiJ4-lMYf5nGaiCRVzhVQVimrGBVh2vr5Dy_5XwOh3kAD9Ugur9yk_Y65dYlEW6MTVGr-8GG8rdo6PHFl7dZy64F3k4fGSvhvzlaABEkkM7PQ6drn5WipWGWyXNLtcemonVprNM-5pJdALSdJVwRGmJpLj2uIAJALe8dwunyG-qc6QJ-plafjkbbLpOK49-bZHS6f8F6LHy7rA80i0lzWGNS9lZ2jFcpz1JzBRDyKLgjk3V_AZc7WmfKQ-fZEOVhdCd30P2qwyWN5-ER1h8iuMdg5nZTkE1cy_8aqeS5JEirLkYFBqcZI20',
    },
    STORE_ID: 'qa3333',
    RESTAURANT_ID: '1L4JRAVV',
    LOCATION_ID: '1L4JRAVV_LOCATION_DEFAULT',
    MENU_ID: '1L4JRAVV_MENU_DEFAULT'
  },
  production: {
    BASE_URL: 'https://daba.store',
    BACKOFFICE_API_URL: 'https://daba.store/live/api',
    WEBSTORE_API_URL: 'https://daba.store/webstore/api',
    BACKOFFICE_URL: 'https://daba.store/backoffice',
    CREDENTIALS: {
      phone: '+212648588997',
      password: '06659534159@Zidan',
      reCaptchaToken: 'production-recaptcha-token'
    },
    STORE_ID: 'qa3333',
    RESTAURANT_ID: 'PROD_RESTAURANT_ID',
    LOCATION_ID: '',
    MENU_ID: 'PROD_MENU_ID'
  }
};

// Function to get environment from env vars or default to beta
export function getEnvironment(): keyof typeof ENVIRONMENTS {
  // Using process.env.ENV_NAME if specified, otherwise default to beta
  return (process.env.ENV_NAME || 'beta') as keyof typeof ENVIRONMENTS;
}

// Get current environment configuration
export const CONFIG = ENVIRONMENTS[getEnvironment()];