
# Project Structure

### `constants`
   - Contains files defining constants such as server endpoints.

### `fixtures`
   - Houses fixtures used for setting up test cases.

### `helpers`
   - Holds helper functions, like validation utilities.

### `test-data`
   - Organized test data for different environments and types.

### `components`
   - Organizes test files based on platform components.
   - **`api`**: API-related tests.
   - **`general`**: General tests applicable across different components of the platform
   - **`restaurant`**: Tests related to restaurant functionality.
   - **`webstore`**: Tests related to the webstore.